Alien orbitable depth mesh package

Open alien-depth-mesh-viewer.html in a browser to orbit/pan/zoom the textured mesh.
Import alien-textured-depth-mesh.obj into Blender or another 3D app; keep the .mtl and alien-texture.jpg in the same folder.

Important: this is a single-image textured depth/relief mesh. It preserves the source image from the front and gives real camera movement, but hidden sides/back are not reconstructed like a true multi-view 3D scan.
