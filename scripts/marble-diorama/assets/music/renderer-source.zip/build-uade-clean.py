from pathlib import Path
import re, subprocess, json
root=Path('work/webuade/emscripten').resolve()
line=next(l for l in (root/'makeEmscripten.bat').read_text().splitlines() if l.startswith('emcc.bat -s WASM=1'))
line=line.split(' && ')[0]
args=line.split()[1:]
# Keep source inputs/includes from upstream, modernize only the build wrapper.
inputs=[a for a in args if a.endswith(('.c','.cpp','.bc')) or a.startswith('-I')]
compiler='D:/Projects/_web_amiga_research/emsdk/upstream/emscripten/emcc.bat'
for name in ['prowiz','unice68']:
    output=root/'built'/f'{name}-modern.o'
    if not output.exists():
        library=next(l.strip() for l in (root/'makeEmscripten.bat').read_text().splitlines() if l.strip().startswith('call emcc.bat') and f'-o built/{name}.bc' in l)
        sources=[a for a in library.split() if a.endswith('.c') or a.startswith(('-I','-D'))]
        result=subprocess.run([compiler,*sources,'-r','-O2','-Wno-error=implicit-function-declaration','-Wno-error=incompatible-function-pointer-types','-Wno-error=int-conversion','-o',str(output)],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        Path(f'work/uade-{name}-build.log').write_text(result.stdout)
        print(name,result.returncode,result.stdout[-1500:])
        if result.returncode: raise SystemExit(result.returncode)
    inputs=[str(output) if a==f'built/{name}.bc' else a for a in inputs]
callback=(root/'callback.js').read_text().replace('Pointer_stringify','UTF8ToString')
(root/'callback-modern.js').write_text(callback)
out=root/'built/clean.cjs'
cmd=['D:/Projects/_web_amiga_research/emsdk/upstream/emscripten/emcc.bat',*inputs,'-O2','-Wno-pointer-sign','-Wno-error=implicit-function-declaration','-Wno-error=incompatible-function-pointer-types','-Wno-error=int-conversion','-s','ALLOW_MEMORY_GROWTH=1','-s','INITIAL_MEMORY=33554432','-s','FORCE_FILESYSTEM=1','-s','MODULARIZE=1','-s','EXPORT_NAME=createUADE','-s','EXPORTED_FUNCTIONS='+json.dumps(['_emu_prepare','_emu_load_file','_emu_compute_audio_samples','_emu_teardown','_emu_get_audio_buffer','_emu_set_subsong','_emu_get_audio_buffer_length','_malloc','_free','_emu_set_panning']),'-s','EXPORTED_RUNTIME_METHODS='+json.dumps(['ccall','getValue','UTF8ToString','FS','FS_createPath','FS_createDataFile']), '--js-library','callback-modern.js','-o',str(out)]
result=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
Path('work/uade-build.log').write_text(result.stdout)
print(result.stdout[-6500:]);raise SystemExit(result.returncode)
