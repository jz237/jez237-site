// QA: ride-ups. Two-car derby; the rival is parked (engine seized) and the player rams its rear at SPEED m/s RAMS times
// (health reset, teleported between rams). For each ram: whether the ride-up fired, the highest the player rose above the
// rival, seconds spent on top (more than 0.45 m above, centres within 2.6 m), whether it ended upside down, the rival's
// rear crush and health after, the ON TOP credits and toasts. Errors too.
import {chromium} from '@playwright/test';
const port=process.env.PORT??'8795',SPEED=+(process.env.SPEED??14),RAMS=+(process.env.RAMS??6);
const browser=await chromium.launch({channel:'chrome',headless:true,args:['--ignore-gpu-blocklist','--enable-gpu']});const errors=[];
try{const page=await browser.newPage({viewport:{width:1280,height:720}});page.on('pageerror',e=>errors.push(e.message.slice(0,160)));page.on('console',m=>{if(m.type()==='error')errors.push(m.text().slice(0,160));});
 await page.goto(`http://127.0.0.1:${port}/`);await page.waitForSelector('#start',{timeout:240000});
 await page.evaluate(()=>{const o=JSON.parse(localStorage.getItem('quarry-impact-events-v1')??'{"version":1}');Object.assign(o,{version:1,field:2,arena:'harrow-bowl-v1',derby:'survival',duration:120});localStorage.setItem('quarry-impact-events-v1',JSON.stringify(o));});
 await page.reload();await page.waitForSelector('#start',{timeout:240000});await page.click('.mode-card[data-mode="derby"]');await page.click('#start');
 await page.waitForFunction(()=>['playing','countdown'].includes(window.__quarry?.state),null,{timeout:180000});
 const r=await page.evaluate(({SPEED,RAMS})=>{for(let i=0;i<20&&__quarry.state!=='playing';i++)__quarry.simulate(.5);const ins=()=>__quarry.inspect();const p3=p=>[p.x??p[0],p.y??p[1],p.z??p[2]];
  const [px,,pz]=p3(ins()[0].position),[qx,,qz]=p3(ins()[1].position),cx=(px+qx)/2,cz=(pz+qz)/2;__quarry.setEngineDamage(1,1);const out=[];
  for(let ram=0;ram<RAMS;ram++){__quarry.setHealth(0,100);__quarry.setHealth(1,100);__quarry.teleport(1,cx,cz+6,0);__quarry.teleport(0,cx,cz-8,0);__quarry.simulate(.4);
   const before=__quarry.stats.rideUps,rear0=ins()[1].structure?.[1]??0;let hit=false,maxDy=0,onTop=0;const toasts=[];
   for(let i=0;i<180;i++){const [a,ay,b]=p3(ins()[0].position),[c,cy,d]=p3(ins()[1].position);if(!hit&&Math.hypot(a-c,b-d)>4.9)__quarry.velocity(0,0,0,SPEED);else hit=true;
    __quarry.setInput({throttle:hit?.6:0,steer:0,brake:0,handbrake:false});__quarry.simulate(1/60);const [a2,ay2,b2]=p3(ins()[0].position),[c2,cy2,d2]=p3(ins()[1].position);const dy=ay2-cy2;maxDy=Math.max(maxDy,dy);const st=ins()[0].status;if(st&&!toasts.includes(st))toasts.push(st);if(dy>.45&&Math.hypot(a2-c2,b2-d2)<2.6)onTop+=1/60;}
   out.push({fired:__quarry.stats.rideUps>before,maxDy:+maxDy.toFixed(2),onTop:+onTop.toFixed(2),inverted:ins()[0].inverted>0,rearCrush:+((ins()[1].structure?.[1]??0)-rear0).toFixed(2),rivalHealth:Math.round(ins()[1].health),toasts:toasts.filter(t=>/ON TOP/.test(t))});}
  return {rams:out,mounts:__quarry.stats.mounts};},{SPEED,RAMS});
 console.log(JSON.stringify({SPEED,...r,errors:errors.slice(0,3)}));
}finally{await browser.close();}
