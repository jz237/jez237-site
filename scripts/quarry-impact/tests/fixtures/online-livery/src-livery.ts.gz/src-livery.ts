export const LIVERY_LIMIT=32;
export const LIVERY_FACES=['left','right','top','front','rear'] as const;
export type LiveryFace=typeof LIVERY_FACES[number];
export const LIVERY_SHAPES=['stripe','circle','star','chevron','checker','number','text','spray','rust','chips'] as const;
export type LiveryShape=typeof LIVERY_SHAPES[number];
export type LiveryLayer={name:string;face:LiveryFace;shape:LiveryShape;color:number;x:number;y:number;width:number;height:number;rotation:number;opacity:number;flip:boolean;hidden:boolean;text:string;seed:number};
export type LiveryGroup={name:string;layers:LiveryLayer[]};
const obj=(v:unknown):Record<string,unknown>=>v!==null&&typeof v==='object'&&!Array.isArray(v)?v as Record<string,unknown>:{};
const num=(v:unknown,f:number,min:number,max:number)=>typeof v==='number'&&Number.isFinite(v)?Math.max(min,Math.min(max,v)):f;
const label=(v:unknown,f:string,n:number)=>typeof v==='string'?v.replace(/[\u0000-\u001f\u007f]/g,'').trim().slice(0,n)||f:f;
export function newLayer(shape:LiveryShape='stripe',face:LiveryFace='left'):LiveryLayer{return{name:shape.toUpperCase(),face,shape,color:shape==='chips'?0xa4a9a8:shape==='rust'?0x99552f:0xf1bd42,x:.5,y:.55,width:.55,height:.2,rotation:0,opacity:1,flip:false,hidden:false,text:shape==='number'?'27':'BLACKRIDGE',seed:1};}
export function normalizeLivery(value:unknown):LiveryLayer[]{
 if(!Array.isArray(value))return [];
 return value.slice(0,LIVERY_LIMIT).flatMap(v=>{const a=obj(v);if(!LIVERY_FACES.includes(a.face as LiveryFace)||!LIVERY_SHAPES.includes(a.shape as LiveryShape))return [];
 const d=newLayer(a.shape as LiveryShape,a.face as LiveryFace);return [{...d,name:label(a.name,d.name,24),text:label(a.text,d.text,16),color:Math.round(num(a.color,d.color,0,0xffffff)),x:num(a.x,.5,-.5,1.5),y:num(a.y,.55,-.5,1.5),width:num(a.width,.55,.02,2),height:num(a.height,.2,.02,2),rotation:num(a.rotation,0,-180,180),opacity:num(a.opacity,1,0,1),flip:a.flip===true,hidden:a.hidden===true,seed:Math.round(num(a.seed,1,0,0xffffffff))}];});
}
export function normalizeGroups(value:unknown):LiveryGroup[]{return Array.isArray(value)?value.slice(0,8).flatMap(v=>{const a=obj(v),layers=normalizeLivery(a.layers);return typeof a.name==='string'&&a.name.trim()&&layers.length?[{name:label(a.name,'Group',32),layers}]:[]}):[];}
/** Transform selected layers around their common center in surface coordinates. */
export function transformLayers(layers:LiveryLayer[],selected:readonly number[],dx=0,dy=0,scale=1,angle=0){
 const chosen=selected.filter(i=>i>=0&&i<layers.length);if(!chosen.length)return normalizeLivery(layers);
 const cx=chosen.reduce((n,i)=>n+layers[i].x,0)/chosen.length,cy=chosen.reduce((n,i)=>n+layers[i].y,0)/chosen.length,c=Math.cos(angle*Math.PI/180),s=Math.sin(angle*Math.PI/180);
 return normalizeLivery(layers.map((l,i)=>{if(!chosen.includes(i))return l;const x=(l.x-cx)*scale,y=(l.y-cy)*scale;return {...l,x:cx+x*c-y*s+dx,y:cy+x*s+y*c+dy,width:l.width*scale,height:l.height*scale,rotation:((l.rotation+angle+540)%360)-180};}));
}
export function mirrorLayer(layer:LiveryLayer):LiveryLayer{return {...layer,face:layer.face==='left'?'right':layer.face==='right'?'left':layer.face==='front'?'rear':layer.face==='rear'?'front':layer.face,x:1-layer.x,rotation:-layer.rotation,flip:layer.shape==='text'||layer.shape==='number'?layer.flip:!layer.flip};}
export const liveryHex=(n:number)=>'#'+n.toString(16).padStart(6,'0');
/** Canvas painting is deterministic; seed is saved with every spray/weathering layer. */
export function drawLivery(ctx:CanvasRenderingContext2D,layers:readonly LiveryLayer[],face:LiveryFace,width:number,height:number,finishMask=false){
 ctx.clearRect(0,0,width,height);
 for(const layer of layers){if(layer.face!==face||layer.hidden)continue;
 ctx.save();ctx.scale(width,height);ctx.translate(layer.x,layer.y);ctx.rotate(layer.rotation*Math.PI/180);ctx.scale(layer.width*(layer.flip?-1:1),layer.height);ctx.globalAlpha=layer.opacity;ctx.fillStyle=finishMask?(layer.shape==='rust'?'#ff0000':layer.shape==='chips'?'#00ff00':'#000000'):liveryHex(layer.color);ctx.strokeStyle=ctx.fillStyle;
 const shape=layer.shape;
 if(shape==='stripe')ctx.fillRect(-.5,-.5,1,1);
 else if(shape==='circle'){ctx.beginPath();ctx.ellipse(0,0,.5,.5,0,0,Math.PI*2);ctx.fill();}
 else if(shape==='star'){ctx.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,r=i%2?.22:.5;ctx.lineTo(Math.cos(a)*r,Math.sin(a)*r);}ctx.closePath();ctx.fill();}
 else if(shape==='chevron'){ctx.beginPath();ctx.moveTo(-.5,-.5);ctx.lineTo(0,0);ctx.lineTo(-.5,.5);ctx.lineTo(0,.5);ctx.lineTo(.5,0);ctx.lineTo(0,-.5);ctx.closePath();ctx.fill();}
 else if(shape==='checker'){for(let x=0;x<8;x++)for(let y=0;y<4;y++)if((x+y)%2===0)ctx.fillRect(x/8-.5,y/4-.5,1/8,1/4);}
 else if(shape==='text'||shape==='number'){ctx.font='900 100px Arial,sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';const text=layer.text||'27',w=ctx.measureText(text).width;ctx.scale(.94/Math.max(w,1),.011);ctx.fillText(text,0,0);}
 else {let state=layer.seed>>>0;const random=()=>((state=(Math.imul(state,1664525)+1013904223)>>>0)/4294967296);
 for(let i=0;i<(shape==='spray'?700:220);i++){const x=random()-.5,y=random()-.5,edge=Math.max(0,1-Math.hypot(x*2,y*2));if(edge===0)continue;ctx.globalAlpha=layer.opacity*edge*(shape==='spray'?.2+random()*.5:.4+random()*.6);const radius=(shape==='spray'?.008:.018)*(1+random()*2);if(shape==='rust'){const shade=.65+random()*.55;if(!finishMask)ctx.fillStyle=`rgb(${Math.floor((layer.color>>16)*shade)},${Math.floor((layer.color>>8&255)*shade)},${Math.floor((layer.color&255)*shade)})`;}if(shape==='chips')ctx.fillRect(x,y,radius,radius*.6);else{ctx.beginPath();ctx.ellipse(x,y,radius*.45,radius*1.5,0,0,Math.PI*2);ctx.fill();}}}
 ctx.restore();
 }
}
