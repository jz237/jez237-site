// QA: decode every clip in public/audio/manifest.json with the browser's decodeAudioData (as the game does) and report
// any that fail, with each clip's decoded length.
import {chromium} from '@playwright/test';
const port=process.env.PORT??'8795';
const browser=await chromium.launch({channel:'chrome',headless:true});
try{const page=await browser.newPage();await page.goto(`http://127.0.0.1:${port}/`);
 const r=await page.evaluate(async()=>{const list=await (await fetch('audio/manifest.json')).json(),c=new OfflineAudioContext(1,44100,44100),out=[];
  for(const e of list){try{const b=await c.decodeAudioData(await (await fetch('audio/'+e.file)).arrayBuffer());out.push([e.id,+b.duration.toFixed(2)]);}catch(err){out.push([e.id,'FAIL '+err.name]);}}return out;});
 console.log(JSON.stringify({failed:r.filter(x=>typeof x[1]==='string'),decoded:r.length}));
}finally{await browser.close();}
