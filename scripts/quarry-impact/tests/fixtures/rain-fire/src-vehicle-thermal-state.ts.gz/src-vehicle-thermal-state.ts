import {unitNoise} from './vehicle-fire-profile';
export const FIRE_CHANCE=.24,EXPLOSION_CHANCE=.12;
/** Engine-bay smoke from engine damage: none below onset, rising to max. */
export const ENGINE_SMOKE={onset:.4,gain:.75,max:.42} as const;
export type DamageZones={front:number;rear:number;left:number;right:number;roof:number};
const noDamage:DamageZones={front:0,rear:0,left:0,right:0,roof:0};
/** One ignition assessment per severe engine/fuel damage episode. */
export class VehicleThermalState {
  health=100;heat=0;smoke=0;soot=0;burst=0;exploded=false;age=0;criticalTime=0;
  burning=false;burnTime=0;ignitionTime=0;
  private episode=0;private eligible=false;private assessed=false;private explosive=false;
  private delay=5;private burstDelay=18;private fuelTime=40;
  /** Seconds into the burn when a ruptured fuel tank goes up (undefined = no leaking tank). */
  private fuelBlast?:number;
  constructor(health=100,private seed=Math.random()){this.health=health;}
  /** engineDamage (offline cars only) adds engine-bay smoke as a failing engine strains. */
  advance(health:number,dt:number,_impactDamage=Math.max(0,this.health-health),zones:DamageZones=noDamage,engineZone:'front'|'rear'='front',waterCooled=true,engineDamage?:number){
    if(!(dt>0)||!Number.isFinite(dt))return false;
    health=Math.max(0,Math.min(100,Number.isFinite(health)?health:this.health));
    if(health>this.health+1)this.reset(health);
    const severe=health<=18&&(zones[engineZone]>=30||zones[engineZone==='front'?'rear':'front']>=36),n=(offset:number)=>unitNoise(this.seed+this.episode*1.173+offset);
    if(severe&&!this.assessed){this.assessed=true;this.eligible=n(0)<FIRE_CHANCE;this.explosive=n(9.37)<EXPLOSION_CHANCE;this.delay=3+n(4.71)*8;this.burstDelay=12+n(7.28)*15;this.fuelTime=30+n(12.19)*40;}
    if(this.eligible&&severe&&!this.burning){this.ignitionTime+=dt;if(this.ignitionTime+1e-9>=this.delay)this.burning=true;}
    if(this.burning)this.burnTime+=dt;
    const fuel=this.burning?Math.min(1,Math.max(0,(this.fuelTime-this.burnTime)/9)):0,target=fuel*(.62+n(2.13)*.32);
    this.heat+=(target-this.heat)*(1-Math.exp(-dt*(target>this.heat?1.45:.6)));
    if(this.burning&&this.heat>.65&&health<=6&&fuel>.5)this.criticalTime+=dt;
    const burst=(this.explosive&&!this.exploded&&this.criticalTime+1e-9>=this.burstDelay)||(this.burning&&!this.exploded&&this.fuelBlast!==undefined&&this.burnTime+1e-9>=this.fuelBlast);
    if(burst){this.exploded=true;this.burst=1;}else this.burst=Math.max(0,this.burst-dt*1.65);
    const coolant=waterCooled&&zones[engineZone]>=12&&health<60?Math.min(.32,(60-health)/120):0,sootTarget=fuel>0?this.heat:0;
    this.soot+=(sootTarget-this.soot)*(1-Math.exp(-dt*.6));
    const strain=engineDamage!==undefined&&Number.isFinite(engineDamage)&&health>0?Math.min(ENGINE_SMOKE.max,Math.max(0,engineDamage-ENGINE_SMOKE.onset)*ENGINE_SMOKE.gain):0;
    const smokeTarget=Math.max(coolant,strain,this.soot*(.65+n(3.18)*.35));this.smoke+=(smokeTarget-this.smoke)*(1-Math.exp(-dt*.85));
    this.health=health;this.age+=dt;return burst;
  }
  /** A burning car leaking fuel blows up 6–12 s into the burn (once per damage episode; offline cars only). */
  primeFuelBlast(){if(this.fuelBlast===undefined&&!this.exploded&&!this.doused)this.fuelBlast=6+unitNoise(this.seed+this.episode*1.173+33.1)*6;}
  /** Put out by water (driving through a puddle): it stops burning, will not relight this damage episode, and a
   * pending fuel-tank blast is cancelled. Heat and smoke die away as they would after the fuel runs out. */
  douse(){if(!this.burning)return false;this.burning=false;this.eligible=false;this.assessed=true;this.ignitionTime=0;this.fuelBlast=undefined;this.doused=true;return true;}
  doused=false;
  /** Set alight from outside (burning fuel or oil under the car): it burns like an engine fire. */
  ignite(){
    if(this.burning)return;this.doused=false;
    this.burning=true;this.assessed=true;this.eligible=true;this.burnTime=0;this.fuelTime=25+unitNoise(this.seed+this.episode*1.173+21.7)*20;
  }
  reset(health=100){this.health=health;this.heat=this.smoke=this.soot=this.burst=this.age=this.criticalTime=this.burnTime=this.ignitionTime=0;this.exploded=this.burning=this.assessed=this.eligible=this.explosive=false;this.fuelBlast=undefined;this.doused=false;this.episode++;}
}
