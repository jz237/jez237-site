import test from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';
import {readFernleighCarPrevious,restoreFernleighCarBytes,verifyFernleighCarRevision} from './fernleigh-car-invariants';
const source=(file:string)=>readFileSync(new URL('../'+file,import.meta.url));
test('FernleighCar preserves every prior fixture, vehicle asset, venue art and history input',verifyFernleighCarRevision);
test('the successor bridge restores full predecessors and does not conceal later or corrupt edits',()=>{
 const manifest=JSON.parse(source('tests/fixtures/fernleigh-car/revision.json').toString());
 for(const file of Object.keys(manifest.files)){
  const bytes=source(file);assert.deepEqual(restoreFernleighCarBytes(file,bytes),readFernleighCarPrevious(file));
  const corrupt=Buffer.concat([bytes,Buffer.from('\ncorrupt')]);assert.deepEqual(restoreFernleighCarBytes(file,corrupt),corrupt);
 }
 const unknown=Buffer.from('unknown');assert.deepEqual(restoreFernleighCarBytes('src/unknown.ts',unknown),unknown);
});
