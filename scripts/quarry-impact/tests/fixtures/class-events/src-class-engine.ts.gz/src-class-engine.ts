import {ENGINE_RESTRICTIONS,type EngineRestriction} from './engine-packages';
import {normalizeSetup,type Setup} from './garage';
import {performanceRating,CLASS_LIMITS,type ClassLimit} from './performance-class';
import type {CarKind} from './rules';
/** Select a real engine package, never alter tyres/armor/tuning to meet a class.
 * The garage remains untouched. No ceiling means preserve the selected engine.
 * Lower-output factory engines replace upgrade stages rather than stacking. */
export function classEngineSetup(kind:CarKind,input:Setup|undefined,limit?:ClassLimit):Setup{
 const source=normalizeSetup(input,kind);if(!limit)return source;
 const {engineRestriction:_,...base}=source;
 const candidates:Setup[]=[...Array.from({length:4},(_,engine)=>({...base,engine})),...Object.keys(ENGINE_RESTRICTIONS).map(engineRestriction=>({...base,engine:0,engineRestriction:engineRestriction as EngineRestriction}))];
 const eligible=candidates.map(setup=>({setup,points:performanceRating(kind,setup).points})).filter(c=>c.points<=CLASS_LIMITS[limit]);
 eligible.sort((a,b)=>b.points-a.points);
 if(!eligible.length)throw new Error('No engine package fits the selected class.');
 return normalizeSetup(eligible[0].setup,kind);
}
