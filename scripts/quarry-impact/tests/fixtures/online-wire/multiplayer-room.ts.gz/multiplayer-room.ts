import {validCapacity} from '../src/online-capacity';
import {newCup,beginCupRound,finishCupRound,nextCupMode,validCup,type CupState,type CupMode} from './cup';
import type Rapier from '@dimforge/rapier3d-compat';
import { Simulation } from './simulation';
import { NEUTRAL, PROTOCOL, parseClientMessage, type Member, type ServerMessage, type Snapshot } from './protocol';
export type Peer = { send(message: ServerMessage): void; close(code: number, reason: string): void; sendEncoded?:(message:string)=>void };
type Session = { cupId:string; voteAt:number; peer: Peer; member: Member; token: string; lastInput: number; seq: number; disconnected: number; rateStart: number; count: number };
export type SavedRoom = { snapshot: Snapshot; sessions: { cupId?:string; member: Member; token: string; disconnected: number; seq: number }[]; updated: number };

export class Room {
  sim: Simulation;
  cup?:CupState;
  sessions = new Map<number, Session>();
  constructor(public code: string, private R: typeof Rapier, public now = () => Date.now()) { this.sim = new Simulation(R); }
  get activeCount() { return [...this.sessions.values()].filter(s=>s.member.connected).length; }
  connect(peer: Peer, raw: string): number | null {
    const hello=parseClientMessage(raw);
    if(!hello||hello.type!=='hello'){peer.close(1008,'Expected valid hello');return null;}
    if(!this.sessions.size&&this.sim.phase==='lobby'&&hello.maxPlayers===24&&this.sim.capacity!==24){this.sim.dispose();this.sim=new Simulation(this.R,'derby',[],24);}
    if(this.sim.capacity===24&&hello.maxPlayers!==24){peer.close(1008,'Update the game to join a 24-driver room.');return null;}
    let session=hello.token?[...this.sessions.values()].find(s=>s.token===hello.token):undefined;
    if(session){
      if(session.member.connected)session.peer.close(4001,'Reconnected elsewhere');
      session.peer=peer;session.member.connected=true;session.disconnected=0;session.lastInput=this.now();session.rateStart=this.now();session.count=0;
    }else{
      const id=Array.from({length:this.sim.capacity},(_,i)=>i).find(i=>!this.sessions.has(i)||(!this.sessions.get(i)!.member.connected&&this.now()-this.sessions.get(i)!.disconnected>60_000));
      if(id===undefined){peer.close(4004,'Room is full');return null;}
      // Mid-event entrants take over the existing AI car, preserving its condition and location.
      session={cupId:crypto.randomUUID(),voteAt:-Infinity,peer,member:{id,name:hello.name,kind:this.sim.phase==='lobby'||this.sim.phase==='result'?hello.kind:this.sim.cars[id].state.kind,connected:true,host:this.sessions.size===0},token:crypto.randomUUID(),lastInput:this.now(),seq:-1,disconnected:0,rateStart:this.now(),count:0};
      this.sessions.set(id,session);
    }
    this.electHost();
    peer.send({type:'welcome',protocol:PROTOCOL,room:this.code,id:session.member.id,token:session.token,snapshot:this.snapshot(true)});
    this.broadcast();return session.member.id;
  }
  receive(id:number,peer:Peer,raw:string){
    const s=this.sessions.get(id);if(!s||s.peer!==peer||!s.member.connected)return;
    if(this.now()-s.rateStart>=1000){s.rateStart=this.now();s.count=0;}
    if(++s.count>90){peer.close(1008,'Input rate exceeded');this.disconnect(id,peer);return;}
    const m=parseClientMessage(raw);if(!m){peer.close(1008,'Invalid message');this.disconnect(id,peer);return;}
    if(m.type==='input'){
      if(m.seq<=s.seq)return;s.seq=m.seq;s.lastInput=this.now();this.sim.setInput(id,m.controls);
    }else if(m.type==='start'){
      if(!s.member.host){peer.send({type:'error',message:'Only the room host can start an event.'});return;}
      if(this.sim.phase!=='lobby'&&this.sim.phase!=='result'){peer.send({type:'error',message:'The event is already running.'});return;}
      if(this.cup&&this.cup.completed<this.cup.rounds){peer.send({type:'error',message:'Continue the current cup using Next round.'});return;}
      this.cup=(m.rounds??1)>1?newCup(m.rounds!,m.mode as CupMode):undefined;
      this.startRound(m.mode);this.broadcast();return true;
    }else if(m.type==='vote'){
      if(!this.cup||this.sim.phase!=='result'||this.cup.completed>=this.cup.rounds){peer.send({type:'error',message:'Voting opens between cup rounds.'});return;}
      if(this.cup.votes[id]===m.mode||this.now()-s.voteAt<250)return;
      s.voteAt=this.now();this.cup.votes[id]=m.mode;this.broadcast();return true;
    }else if(m.type==='next'){
      if(!s.member.host){peer.send({type:'error',message:'Only the room host can advance the cup.'});return;}
      if(!this.cup||this.sim.phase!=='result'||this.cup.completed>=this.cup.rounds){peer.send({type:'error',message:'There is no next cup round.'});return;}
      this.startRound(nextCupMode(this.cup,new Set([...this.sessions].filter(([,s])=>s.member.connected).map(([id])=>id))));this.broadcast();return true;
    }else if(m.type==='recover'){if(this.sim.recover(id))this.broadcast();}
    else if(m.type==='ping')peer.send({type:'pong',sent:m.sent});
  }
  disconnect(id:number,peer:Peer){const s=this.sessions.get(id);if(!s||s.peer!==peer)return;s.member.connected=false;s.disconnected=this.now();if(this.cup)delete this.cup.votes[id];this.sim.setInput(id,{...NEUTRAL});this.electHost();this.broadcast();}
  private electHost(){let host=[...this.sessions.values()].find(s=>s.member.connected&&s.member.host);host??=[...this.sessions.values()].find(s=>s.member.connected);for(const s of this.sessions.values())s.member.host=s===host;}
  step(){const human=new Set<number>();for(const [id,s]of this.sessions){if(s.member.connected){human.add(id);if(this.now()-s.lastInput>350)this.sim.setInput(id,{...NEUTRAL});}}this.sim.step(human);this.settleCup();}
  snapshot(includeDamage=false):Snapshot{this.settleCup();return {...this.sim.snapshot(includeDamage),cupSupport:true,...(this.cup?{cup:structuredClone(this.cup)}:{}),members:[...this.sessions.values()].map(s=>({...s.member,cupId:s.cupId})),ack:Object.fromEntries([...this.sessions].map(([id,s])=>[id,s.seq]))};}
  broadcast(){const snap=this.snapshot();let encoded:string|undefined;for(const s of this.sessions.values())if(s.member.connected)try{if(s.peer.sendEncoded)s.peer.sendEncoded(encoded??=JSON.stringify(snap));else s.peer.send(snap);}catch{s.member.connected=false;s.disconnected=this.now();}this.electHost();}
  save():SavedRoom{return{snapshot:this.snapshot(true),sessions:[...this.sessions.values()].map(s=>({cupId:s.cupId,member:{...s.member},token:s.token,disconnected:s.disconnected,seq:s.seq})),updated:this.now()};}
  restore(saved:SavedRoom){this.sim.dispose();const capacity=saved.snapshot.capacity??saved.snapshot.cars.length;if(!validCapacity(capacity)||capacity!==saved.snapshot.cars.length)throw new Error('Invalid saved room capacity');this.sim=new Simulation(this.R,saved.snapshot.mode,saved.snapshot.cars.map(c=>c.kind),capacity);this.sim.restore(saved.snapshot);this.cup=validCup(saved.snapshot.cup)?structuredClone(saved.snapshot.cup):undefined;this.sessions.clear();for(const s of saved.sessions)this.sessions.set(s.member.id,{...s,cupId:s.cupId??crypto.randomUUID(),voteAt:-Infinity,member:{...s.member,connected:false},peer:{send(){},close(){}},lastInput:0,rateStart:0,count:0,disconnected:s.disconnected||this.now()});}
  private startRound(mode:'race'|'derby'|'playground'){
    if(this.cup)beginCupRound(this.cup,mode as CupMode,Array.from({length:this.sim.capacity},(_,id)=>{const session=this.sessions.get(id);return session?.member.connected?{id:session.cupId,name:session.member.name,bot:false}:{id:'bot-'+id,name:'AI DRIVER '+(id+1),bot:true};}));
    const kinds=Array.from({length:this.sim.capacity},(_,i)=>this.sessions.get(i)?.member.kind??this.sim.cars[i].state.kind);
    const capacity=this.sim.capacity;this.sim.dispose();this.sim=new Simulation(this.R,mode,kinds,capacity);this.sim.start();
    for(const session of this.sessions.values()){session.lastInput=0;session.voteAt=-Infinity;}
  }
  private settleCup(){
    if(!this.cup||this.sim.phase!=='result'||this.cup.completed===this.cup.round)return;
    const eligible=new Set(this.cup.entries.filter(e=>e.bot).map(e=>e.id));
    for(const [slot,session]of this.sessions)if(session.member.connected&&this.cup.participants[slot]===session.cupId)eligible.add(session.cupId);
    finishCupRound(this.cup,this.sim.ranking(),eligible);
  }
  dispose(){this.sim.dispose();}
}
