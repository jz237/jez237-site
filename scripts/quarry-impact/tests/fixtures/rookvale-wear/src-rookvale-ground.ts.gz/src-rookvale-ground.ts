import * as T from 'three';
import {ROOKVALE,ROOKVALE_LANES} from './rookvale-course';
import {addCourseGroundDetail} from './course-materials';
/** Material-only distance includes the open cross-yard roads. Physics still uses ROOKVALE. */
export function rookvaleGroundDistance(x:number,z:number){
 let distance=ROOKVALE.distance(x,z);
 for(const lane of ROOKVALE_LANES){const [a,b]=lane.points,dx=b.x-a.x,dz=b.z-a.z,t=T.MathUtils.clamp(((x-a.x)*dx+(z-a.z)*dz)/(dx*dx+dz*dz),0,1);
  // The shared material's road reference is 24m wide; compensate narrower yard lanes.
  distance=Math.min(distance,Math.hypot(x-a.x-t*dx,z-a.z-t*dz)+12-lane.width/2);
 }
 return distance;
}
export function addRookvaleGroundDetail(material:T.MeshStandardMaterial){
 const detail=addCourseGroundDetail(material,{...ROOKVALE,distance:rookvaleGroundDistance}),compile=material.onBeforeCompile;
 material.onBeforeCompile=(shader,renderer)=>{compile.call(material,shader,renderer);shader.fragmentShader=shader.fragmentShader.replace('diffuseColor.rgb=mix(courseFinish,coursePaint,courseMark);',`// Yard labels and loading-apron paint also occur outside the racing lanes.
courseMark=max(courseMark,smoothstep(.4,.55,max(max(coursePaint.r,coursePaint.g),coursePaint.b)));
diffuseColor.rgb=mix(courseFinish,coursePaint,courseMark);`);};
 material.customProgramCacheKey=()=> 'rookvale-photo-ground-v1';return detail;
}
