// QA: running-gear loops. Four-car derby with audio allowed, rivals away. The player holds reverse from a standstill:
// __quarry.whining() must list the player while backing up and drop it after; then a shredding tyre at 10 m/s must flap
// (__quarry.flapping) and a leaking radiator on a running engine must hiss (__quarry.hissing); all three clips must decode.
import {chromium} from '@playwright/test';
const port=process.env.PORT??'8795';
const browser=await chromium.launch({channel:'chrome',headless:true,args:['--ignore-gpu-blocklist','--enable-gpu','--autoplay-policy=no-user-gesture-required']});const errors=[];
try{const page=await browser.newPage({viewport:{width:1280,height:720}});page.on('pageerror',e=>errors.push(e.message.slice(0,160)));page.on('console',m=>{if(m.type()==='error')errors.push(m.text().slice(0,160));});
 await page.goto(`http://127.0.0.1:${port}/`);await page.waitForSelector('#start',{timeout:240000});
 await page.evaluate(()=>{const o=JSON.parse(localStorage.getItem('quarry-impact-events-v1')??'{"version":1}');Object.assign(o,{version:1,field:4,arena:'harrow-bowl-v1',derby:'survival',duration:180});localStorage.setItem('quarry-impact-events-v1',JSON.stringify(o));});
 await page.reload();await page.waitForSelector('#start',{timeout:240000});await page.click('.mode-card[data-mode="derby"]');await page.click('#start');
 await page.waitForFunction(()=>window.__quarry?.state==='playing',null,{timeout:180000});await page.waitForTimeout(800);
 await page.evaluate(()=>{const [px,,pz]=__quarry.inspect()[0].position;for(const i of [1,2,3]){__quarry.setEngineDamage(i,1);__quarry.teleport(i,px+60*(i-2),pz+60,0);}});await page.waitForTimeout(600);
 const idle=await page.evaluate(()=>__quarry.whining());await page.keyboard.down('KeyS');await page.waitForTimeout(1800);
 const reversing=await page.evaluate(()=>({whining:__quarry.whining(),speed:__quarry.inspect()[0].speed}));await page.keyboard.up('KeyS');await page.waitForTimeout(2500);
 const stopped=await page.evaluate(()=>({whining:__quarry.whining(),speed:__quarry.inspect()[0].speed}));
 // A shredding tyre at speed flaps; a leaking radiator on a running engine hisses.
 await page.evaluate(()=>{__quarry.shredTyre(0,0);const [fx,,fz]=__quarry.inspect()[0].forward;__quarry.velocity(0,fx*10,0,fz*10);});await page.waitForTimeout(500);
 const flapping=await page.evaluate(()=>__quarry.flapping());
 await page.evaluate(()=>__quarry.setStructure(0,0,.8));await page.keyboard.down('KeyW');await page.waitForTimeout(2500);const hissing=await page.evaluate(()=>__quarry.hissing());await page.keyboard.up('KeyW');
 const decoded=await page.evaluate(async()=>{const out={};for(const id of ['reverse-whine','tyre-flap','steam-hiss']){try{out[id]=+(await new OfflineAudioContext(1,44100,44100).decodeAudioData(await (await fetch(`audio/${id}.ogg`)).arrayBuffer())).duration.toFixed(2);}catch(e){out[id]=String(e).slice(0,60);}}return out;});
 console.log(JSON.stringify({idle,reversing,stopped,flapping,hissing,decoded,errors:errors.slice(0,3)}));
}finally{await browser.close();}
