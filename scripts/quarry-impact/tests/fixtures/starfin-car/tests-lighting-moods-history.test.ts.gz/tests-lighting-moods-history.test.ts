import test from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';
import {readLightingMoodsPrevious,restoreLightingMoodsBytes,verifyLightingMoodsRevision} from './lighting-moods-invariants';
const source=(file:string)=>readFileSync(new URL('../'+file,import.meta.url));
test('LightingMoods preserves every prior fixture, vehicle asset, control and camera input',verifyLightingMoodsRevision);
test('the successor bridge restores full predecessors and does not conceal later or corrupt edits',()=>{
 const manifest=JSON.parse(source('tests/fixtures/lighting-moods/revision.json').toString());
 for(const file of Object.keys(manifest.files)){
  const bytes=source(file);assert.deepEqual(restoreLightingMoodsBytes(file,bytes),readLightingMoodsPrevious(file));
  const corrupt=Buffer.concat([bytes,Buffer.from('\ncorrupt')]);assert.deepEqual(restoreLightingMoodsBytes(file,corrupt),corrupt);
 }
 const unknown=Buffer.from('unknown');assert.deepEqual(restoreLightingMoodsBytes('src/unknown.ts',unknown),unknown);
});
