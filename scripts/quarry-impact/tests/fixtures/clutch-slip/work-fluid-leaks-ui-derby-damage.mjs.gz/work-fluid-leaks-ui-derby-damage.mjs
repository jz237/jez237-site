// QA: a 24-car demo derby at Kestrel (full derby damage); after WAIT seconds, tally blowouts, stripped gearboxes, leaks.
import {chromium} from '@playwright/test';
const port=process.env.PORT??'8795',wait=+(process.env.WAIT??40);
const browser=await chromium.launch({channel:'chrome',headless:true,args:['--ignore-gpu-blocklist','--enable-gpu']});const errors=[];
try{const page=await browser.newPage({viewport:{width:1280,height:720}});page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text().slice(0,200));});
 await page.goto(`http://127.0.0.1:${port}/`);await page.waitForSelector('#demo-options',{timeout:240000});
 await page.click('#demo-options');await page.waitForSelector('#demo-setup');
 await page.selectOption('#demo-arena','kestrel-ring-v1');await page.fill('#demo-field','24');await page.selectOption('#demo-loop','stop');
 await page.click('#demo-begin-derby');await page.waitForFunction(()=>window.__quarry?.state==='playing',null,{timeout:180000});
 await page.evaluate(()=>__quarry.mute?.());await page.waitForTimeout(wait*1000);
 const r=await page.evaluate(()=>{const c=__quarry.inspect();return{fuel:c.map(x=>Math.round((x.fuelLevel??1)*100)).sort((a,b)=>a-b),cars:c.length,alive:c.filter(x=>x.health>0).length,blowouts:c.reduce((s,x)=>s+x.blownOut.filter(Boolean).length,0),gearboxes:c.filter(x=>x.gearLimit<5).map(x=>x.gearLimit),springs:c.reduce((n,x)=>n+x.brokenSprings,0),shafts:c.reduce((n,x)=>n+x.brokenShafts,0),seized:c.filter(x=>x.seized).length,leaking:c.filter(x=>x.drips[0]+x.drips[1]>0).length,structure:c.map(x=>(x.structure??[]).map(n=>+n.toFixed(2))),tyres:c.map(x=>(x.tyreDamage??[]).map(n=>+n.toFixed(2))),wheels:c.map(x=>Array.from(x.wheelDamage??[]).map(n=>+n.toFixed(2))),slicks:__quarry.slicks,rattles:__quarry.audioState.damage};});
 console.log(JSON.stringify({...r,errors:errors.slice(0,5)}));
}finally{await browser.close();}
