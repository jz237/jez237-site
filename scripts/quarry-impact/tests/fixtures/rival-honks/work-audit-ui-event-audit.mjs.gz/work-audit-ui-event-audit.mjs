// QA: how often each destruction showpiece actually happens. A 24-car demo derby at ARENA (default Kestrel) for SECS
// seconds; then sums, over every car, the event counters the inspect snapshot exposes (each field checked to exist), so a
// feature that never fires stands out. Reports the totals and page errors.
import {chromium} from '@playwright/test';
const port=process.env.PORT??'8795',SECS=+(process.env.SECS??180);
const browser=await chromium.launch({channel:'chrome',headless:true,args:['--ignore-gpu-blocklist','--enable-gpu']});const errors=[];
try{const page=await browser.newPage({viewport:{width:1280,height:720}});page.on('pageerror',e=>errors.push(e.message.slice(0,160)));
 await page.goto(`http://127.0.0.1:${port}/`);await page.waitForSelector('#demo-options',{timeout:240000});
 await page.click('#demo-options');await page.waitForSelector('#demo-setup');
 await page.selectOption('#demo-arena',process.env.ARENA??'kestrel-ring-v1');await page.fill('#demo-field','24');await page.selectOption('#demo-loop','stop');
 await page.click('#demo-begin-derby');await page.waitForFunction(()=>window.__quarry?.state==='playing',null,{timeout:180000});await page.evaluate(()=>__quarry.mute?.());
 await page.waitForTimeout(SECS*1000);
 const r=await page.evaluate(()=>{const c=__quarry.inspect(),sum=k=>c.reduce((s,x)=>s+(typeof x[k]==='boolean'?(x[k]?1:0):(x[k]??0)),0),out={};
  for(const k of ['wheelsShed','engineOut','tankDown','tankGone','rodThrown','rubFires','exhaustGone','exhaustCrushed','seized','wingsTorn','doorsTorn','glassPops','debeads','brakeFires','engineFires','smashFires','batteryOut','bumpStarts','throttleCable','handbrakeCable','propSnapped','beltSnapped','spareWheels','cargoSpilled','blownUp','rolls'])out[k]=c.some(x=>k in x)?sum(k):'MISSING';
  const s=__quarry.stats;for(const k of ['rideUps','mounts','tipOvers','blowUps','chainIgnitions','shrapnelHits','aiFireOuts','pileUps','wallSlams','mirrorsClipped'])out[k]=s?.[k]??'MISSING';out.alive=__quarry.cars.filter(x=>x.health>0).length;
  out.signs={};for(let i=0;i<__quarry.cars.length;i++){const f=__quarry.roofSign?.(i)?.fate??'none';out.signs[f]=(out.signs[f]??0)+1;}
  out.driversSlumped=__quarry.cars.map((x,i)=>__quarry.driverSway?.(i)?.drop??0).filter(d=>d>.01).length;out.litter=__quarry.litter?.()??'MISSING';out.bailed=__quarry.bailed?.().length??'MISSING';
  let flags=0,snapped=0;for(let i=0;i<__quarry.cars.length;i++){const f=__quarry.flag?.(i);if(f){flags++;if(f.snapped)snapped++;}}out.flags={flags,snapped};out.smoky=__quarry.cars.map((x,i)=>__quarry.cabinSmoke?.(i)??0).filter(v=>v>.1).length;return out;});
 console.log(JSON.stringify({SECS,...r,errors:errors.slice(0,3)}));
}finally{await browser.close();}
