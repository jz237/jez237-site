import {restoreKeyboardDefaultBytes} from './keyboard-default-invariants';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const read=(path:string)=>readFileSync(new URL('./fixtures/abs/'+path,import.meta.url));
const hash=(bytes:Uint8Array)=>createHash('sha256').update(bytes).digest('hex');
const revision=()=>JSON.parse(read('revision.json').toString());
export function readAbsPrevious(file:string):Buffer{
 const entry=revision().files[file];assert.ok(entry,'No Abs baseline for '+file);
 const bytes=gunzipSync(read(entry.snapshot));assert.equal(hash(bytes),entry.before,file);return bytes;
}
export function restoreAbsBytes(file:string,bytes:Buffer):Buffer{
 const entry=revision().files[file];if(!entry||hash(bytes)!==entry.after)return bytes;
 return readAbsPrevious(file);
}
export function verifyAbsRevision(){
 const manifest=revision();assert.equal(manifest.baseline,'ef74d5fd6aecdec6bf483fa89c2fefcf9272bb71');
 for(const [file,entry]of Object.entries<any>(manifest.files)){
  const bytes=restoreKeyboardDefaultBytes(file,readFileSync(new URL('../'+file,import.meta.url))); assert.equal(hash(bytes),entry.after,file);
  assert.equal(hash(restoreAbsBytes(file,bytes)),entry.before,file);
 }
 for(const [file,expected]of Object.entries<string>(manifest.protected))assert.equal(hash(restoreKeyboardDefaultBytes(file,readFileSync(new URL('../'+file,import.meta.url)))),expected,file+' is outside the Abs release');
 assert.equal(manifest.previousFixtureCount,1499);assert.equal(Object.keys(manifest.protected).filter(file=>file.startsWith('tests/fixtures/')).length,1499);
}
