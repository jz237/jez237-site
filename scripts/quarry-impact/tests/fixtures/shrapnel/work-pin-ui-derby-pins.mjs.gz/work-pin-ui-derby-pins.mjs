// QA: a 24-car demo derby at Kestrel; after WAIT seconds, tally pins suffered, bump starts, ride-ups, mounts, cars upside down, rolls, batteries out, thrown rods, rub fires, seized engines, stalled engines, cars pinned right now, AI phases,
// cars alive and page errors (ARENA picks another arena).
import {chromium} from '@playwright/test';
const port=process.env.PORT??'8795',wait=+(process.env.WAIT??50);
const browser=await chromium.launch({channel:'chrome',headless:true,args:['--ignore-gpu-blocklist','--enable-gpu']});const errors=[];
try{const page=await browser.newPage({viewport:{width:1280,height:720}});page.on('pageerror',e=>errors.push(e.message));
 await page.goto(`http://127.0.0.1:${port}/`);await page.waitForSelector('#demo-options',{timeout:240000});
 await page.click('#demo-options');await page.waitForSelector('#demo-setup');
 await page.selectOption('#demo-arena',process.env.ARENA??'kestrel-ring-v1');await page.fill('#demo-field','24');await page.selectOption('#demo-loop','stop');
 await page.click('#demo-begin-derby');await page.waitForFunction(()=>window.__quarry?.state==='playing',null,{timeout:180000});
 await page.evaluate(()=>__quarry.mute?.());await page.waitForTimeout(wait*1000);
 const r=await page.evaluate(()=>{const c=__quarry.inspect();return{pins:c.reduce((s,x)=>s+(x.pins??0),0),wallSlams:__quarry.stats?.wallSlams,sandwiches:__quarry.stats?.sandwiches,dominoes:__quarry.stats?.dominoes,pinEscapes:__quarry.stats?.pinEscapes,locks:__quarry.stats?.bumperLocks,tethers:__quarry.stats?.tethers,pileUps:__quarry.stats?.pileUps,bumpStarts:__quarry.stats?.bumpStarts,rideUps:__quarry.stats?.rideUps,mounts:__quarry.stats?.mounts,upsideDown:c.filter(x=>x.inverted>0).length,rolls:c.reduce((s,x)=>s+(x.rolls??0),0),batteriesOut:c.filter(x=>x.batteryOut).length,rods:c.filter(x=>x.rodThrown).length,rubFires:c.reduce((s,x)=>s+(x.rubFires??0),0),seized:c.filter(x=>x.seized).length,stalledNow:c.filter(x=>x.engineStall>0&&!x.seized).length,starterFails:c.reduce((s,x)=>s+(x.starterFails??0),0),tanksDown:c.filter(x=>x.tankDown).length,rollPops:c.reduce((s,x)=>s+(x.rollPops??0),0),tanksGone:c.filter(x=>x.tankGone).length,biggestPileUp:__quarry.stats?.biggestPileUp,looseBumpers:c.reduce((s,x)=>s+(x.doors??[]).filter(d=>/bumper/.test(d.name)&&!d.gone&&d.loose>=.35).length,0),pinnedNow:c.filter(x=>x.pinTime>0).length,phases:Object.entries(c.reduce((m,x)=>(m[x.aiPhase??"-"]=(m[x.aiPhase??"-"]??0)+1,m),{})),alive:__quarry.cars.filter(x=>x.health>0).length};});
 console.log(JSON.stringify({port,wait,...r,errors:errors.slice(0,3)}));
}finally{await browser.close();}
