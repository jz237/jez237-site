import * as T from 'three';
/** Working lamps for low-light moods: headlamp lenses and tail lamps glow (brighter tails
 * under braking) and a soft additive pool of light sits on the road ahead. Lamp meshes are
 * found by their material names (Headlight / Lens; Brakelight / Tail Lens) and their position
 * along the car, so every model works without per-car tables. Off by default. */
/** A lamp knocked off, or dented past this much damage, is smashed and stays dark. */
export const LAMP_BREAK=10;
/** Tail lamp glow: lit for the mood (running) or braking with the lamps on, and braking in daylight, bright enough to read in sun. */
export const TAIL_GLOW={running:1.1,braking:3.2,daylightBraking:3} as const;
/** A smashed lamp's lens goes dark (its colour times shade) and dull (roughness at least rough): an empty socket and shards. */
export const BROKEN_LENS={shade:.3,rough:.85} as const;
/** Rain (offline): drivers run their lamps in the gloom, lenses and tails lit as at dusk, but the pool of light on the
 * road is only RAIN_LIGHTS.pool as strong against the daylight. */
export const RAIN_LIGHTS={pool:.45} as const;
/** Rain (offline): each side's headlamp beam shows in the falling rain as a faint cone of light, RAIN_BEAMS.length m long and
 * RAIN_BEAMS.spread m across at its far end, dipped RAIN_BEAMS.dip rad, fading along its length and at its edges, at the
 * strength the caller gives (RAIN_BEAMS.strength in rain, 0 hides it); a side with every lamp smashed throws none. */
export const RAIN_BEAMS={length:9,spread:1.1,dip:.06,strength:.3} as const;
/** A lens reaching past LAMP_BAR.span m either side of the middle is a pair of lamps under one cover: it shines from both
 * ends, LAMP_BAR.inset m in from each. */
export const LAMP_BAR={span:.25,inset:.18} as const;
const HEAD=/headlight|(^|\s)lens$/i,TAIL=/brakelight|tail lens/i,NOT_HEAD=/tail|amber|reverse|indicator|signal|brake/i;
let poolTexture:T.Texture|null=null;
function lightPool(){
 if(poolTexture||typeof document==='undefined')return poolTexture;
 const c=document.createElement('canvas');c.width=128;c.height=256;const ctx=c.getContext('2d');if(!ctx)return null;
 // A soft elliptical beam that fades to nothing well inside the texture edges.
 ctx.translate(64,26);ctx.scale(1,3.4);const g=ctx.createRadialGradient(0,0,2,0,0,60);g.addColorStop(0,'rgba(255,238,200,0.95)');g.addColorStop(.4,'rgba(255,228,175,0.42)');g.addColorStop(.75,'rgba(255,222,165,0.12)');g.addColorStop(1,'rgba(255,220,160,0)');
 ctx.fillStyle=g;ctx.fillRect(-64,-8,128,72);
 // Fade in from the car's end (the top rows) so the pool has no hard edge where it starts under the bumper.
 ctx.setTransform(1,0,0,1,0,0);ctx.globalCompositeOperation='destination-in';const fade=ctx.createLinearGradient(0,0,0,56);fade.addColorStop(0,'rgba(0,0,0,0)');fade.addColorStop(1,'rgba(0,0,0,1)');ctx.fillStyle=fade;ctx.fillRect(0,0,128,256);
 poolTexture=new T.CanvasTexture(c);poolTexture.colorSpace=T.SRGBColorSpace;return poolTexture;
}
/** A crushed front knocks the lamps askew: the pool of light swings toward the more crushed corner and falls short. */
export const HEADLIGHT_AIM={yaw:.4,short:.45} as const;
export function headlightAim(front:number,left:number,right:number){
 const c=(v:number)=>Math.max(0,Math.min(1,Number.isFinite(v)?v:0)),f=c(front);
 return{yaw:(c(right)-c(left))*HEADLIGHT_AIM.yaw*(.5+f)+(f>0?HEADLIGHT_AIM.yaw*.25*f*(c(right)>=c(left)?1:-1):0),reach:1-HEADLIGHT_AIM.short*f};
}
export type CarLights={readonly head:number;readonly tail:number;readonly working:number;readonly lit:boolean;
 /** Lamps on or off, braking, and the road pool's strength 0–1 (1 at dusk). */
 set(on:boolean,braking?:boolean,pool?:number,beam?:number):void;aim(yaw:number,reach:number):void;dispose():void;
 /** Told where a lamp is when it first breaks (its lens centre in the world), head or tail. */
 onSmash?:(at:T.Vector3,kind:'head'|'tail')=>void;
 /** A lamp mesh, for QA. */
 lamp(kind:'head'|'tail',index:number):T.Mesh|undefined;
 /** Push where this car's lamps are shining from now (world space): each side's lit, unsmashed headlamps, and tail lamps
  * while lit or braking. */
 glows(out:{x:number;y:number;z:number;tail:boolean}[],root:T.Object3D):void};
export function attachCarLights(root:T.Object3D,halfLength:number):CarLights{
 root.updateMatrixWorld(true);
 const inverse=root.matrixWorld.clone().invert(),centre=new T.Vector3(),box=new T.Box3();
 // The road under the car (its lowest point, the tyres) in the root's space: the pool of light lies just above it.
 const floor=new T.Box3().setFromObject(root).min.y-root.getWorldPosition(new T.Vector3()).y,poolY=(Number.isFinite(floor)?floor:0)+.06;
 const heads:T.Mesh[]=[],tails:T.Mesh[]=[];
 root.traverse(o=>{
  if(!(o instanceof T.Mesh)||Array.isArray(o.material))return;const name=(o.material as T.Material).name??'';
  box.setFromObject(o).getCenter(centre);centre.applyMatrix4(inverse);
  if(HEAD.test(name)&&!NOT_HEAD.test(name)&&centre.z>halfLength*.35)heads.push(o);
  else if(TAIL.test(name)&&centre.z< -halfLength*.35)tails.push(o);
 });
 // Each car gets its own lamp materials so one car's lights never switch another's.
 const owned:T.Material[]=[];
 const own=(mesh:T.Mesh,color:number)=>{const m=(mesh.material as T.MeshStandardMaterial).clone();m.emissive=new T.Color(color);m.emissiveIntensity=0;mesh.material=m;owned.push(m);return m;};
 const headMats=heads.map(m=>own(m,0xfff1d0)),tailMats=tails.map(m=>own(m,0xff2a1a));
 const pool=lightPool(),poolMaterial=new T.MeshBasicMaterial({map:pool,color:0xffffff,transparent:true,opacity:0,blending:T.AdditiveBlending,depthWrite:false,toneMapped:false}),poolGeometry=new T.PlaneGeometry(4.6,11);
 const poolMesh=new T.Mesh(poolGeometry,poolMaterial);poolMesh.name='car_light_pool';poolMesh.rotation.x=-Math.PI/2;poolMesh.position.set(0,poolY,halfLength+5.2);poolMesh.renderOrder=2;poolMesh.visible=false;poolMesh.frustumCulled=true;
 if(pool&&heads.length)root.add(poolMesh);
 // Where each lamp shines from (root space): its middle, or both ends when one lens spans the car.
 const lampPoints=(list:T.Mesh[])=>list.flatMap((m,i)=>{box.setFromObject(m);const lo=box.min.clone().applyMatrix4(inverse),hi=box.max.clone().applyMatrix4(inverse),c=box.getCenter(new T.Vector3()).applyMatrix4(inverse),minX=Math.min(lo.x,hi.x),maxX=Math.max(lo.x,hi.x);
  return minX< -LAMP_BAR.span&&maxX>LAMP_BAR.span?[{i,c:new T.Vector3(minX+LAMP_BAR.inset,c.y,c.z)},{i,c:new T.Vector3(maxX-LAMP_BAR.inset,c.y,c.z)}]:[{i,c}];});
 // A beam per side of the car from its headlamps' middle, for the rain.
 const beamGeometry=new T.ConeGeometry(RAIN_BEAMS.spread,RAIN_BEAMS.length,16,1,true).rotateX(-Math.PI/2).translate(0,0,RAIN_BEAMS.length/2);
 const beamMaterial=new T.ShaderMaterial({uniforms:{strength:{value:0},color:{value:new T.Color(0xfff1d0)}},transparent:true,depthWrite:false,blending:T.AdditiveBlending,side:T.DoubleSide,
  vertexShader:`varying float vAlong;varying vec3 vNormal2;varying vec3 vView;void main(){vAlong=position.z/${RAIN_BEAMS.length}.;vec4 mv=modelViewMatrix*vec4(position,1.);vNormal2=normalize(normalMatrix*normal);vView=normalize(-mv.xyz);gl_Position=projectionMatrix*mv;}`,
  fragmentShader:`uniform float strength;uniform vec3 color;varying float vAlong;varying vec3 vNormal2;varying vec3 vView;void main(){float t=clamp(vAlong,0.,1.),a=strength*pow(1.-t,1.6)*smoothstep(0.,.06,t)*pow(abs(dot(normalize(vNormal2),normalize(vView))),1.3);gl_FragColor=vec4(color*a,a);}`});
 const beams=([-1,1] as const).map(side=>{
  const lamps=lampPoints(heads).filter(l=>Math.sign(l.c.x||1)===side);if(!lamps.length)return null;
  const mesh=new T.Mesh(beamGeometry,beamMaterial);mesh.name='car_light_beam';mesh.position.copy(lamps.reduce((s,l)=>s.add(l.c),new T.Vector3()).multiplyScalar(1/lamps.length));
  mesh.rotation.order='YXZ';mesh.rotation.x=RAIN_BEAMS.dip;mesh.renderOrder=2;mesh.visible=false;root.add(mesh);return {mesh,lamps:lamps.map(l=>l.i)};
 }).filter(b=>b!==null);
 // Each side's lamps and their middle, for the light they throw.
 const sidesOf=(list:T.Mesh[])=>([-1,1] as const).map(side=>{const ls=lampPoints(list).filter(l=>Math.sign(l.c.x||1)===side);
  return ls.length?{at:ls.reduce((sum,l)=>sum.add(l.c),new T.Vector3()).multiplyScalar(1/ls.length),lamps:ls.map(l=>l.i)}:null;}).filter(b=>b!==null);
 const headSides=sidesOf(heads),tailSides=sidesOf(tails),glowAt=new T.Vector3();
 let lit=false,brake=false,broken=-1,level=1,beamLevel=0;
 const smashed=(m:T.Mesh)=>!m.visible||(m.userData.damage??0)>LAMP_BREAK;
 const api:CarLights={head:heads.length,tail:tails.length,get working(){return heads.filter(m=>!smashed(m)).length;},get lit(){return lit;},
  set(on,braking=false,poolLevel=1,beam=0){
   const strength=Number.isFinite(poolLevel)?Math.max(0,Math.min(1,poolLevel)):1,shine=Number.isFinite(beam)?Math.max(0,Math.min(1,beam)):0;
   let mask=0;heads.forEach((m,i)=>{if(smashed(m))mask|=1<<i;});tails.forEach((m,i)=>{if(smashed(m))mask|=1<<(i+16);});
   // A lamp that has just broken leaves its pieces where it was.
   if(broken>=0&&api.onSmash)for(const [list,shift,kind] of [[heads,0,'head'],[tails,16,'tail']] as const)list.forEach((m,i)=>{if(mask&1<<(i+shift)&&!(broken&1<<(i+shift)))api.onSmash!(box.setFromObject(m).getCenter(new T.Vector3()),kind);});
   // and its lens goes dark and dull, once.
   if(broken>=0)for(const [list,shift] of [[headMats,0],[tailMats,16]] as const)list.forEach((m,i)=>{if(mask&1<<(i+shift)&&!(broken&1<<(i+shift))){m.color.multiplyScalar(BROKEN_LENS.shade);m.roughness=Math.max(m.roughness,BROKEN_LENS.rough);}});
   if(on===lit&&braking===brake&&mask===broken&&strength===level&&shine===beamLevel)return;
   const intact=heads.length?heads.filter((_,i)=>!(mask&1<<i)).length/heads.length:0;
   headMats.forEach((m,i)=>{m.emissiveIntensity=on&&!(mask&1<<i)?2.4:0;});
   poolMesh.visible=on&&!!pool&&intact>0;poolMaterial.opacity=on?.38*intact*strength:0;
   tailMats.forEach((m,i)=>{m.emissiveIntensity=mask&1<<(i+16)?0:on?(braking?TAIL_GLOW.braking:TAIL_GLOW.running):(braking?TAIL_GLOW.daylightBraking:0);});
   beamMaterial.uniforms.strength.value=shine;for(const b of beams)b.mesh.visible=on&&shine>0&&b.lamps.some(i=>!(mask&1<<i));
   lit=on;brake=braking;broken=mask;level=strength;beamLevel=shine;
  },
  aim(yaw,reach){
   const y=Number.isFinite(yaw)?yaw:0,r=Math.max(.3,Math.min(1,Number.isFinite(reach)?reach:1)),d=halfLength+5.2*r;
   poolMesh.rotation.set(-Math.PI/2,0,y);poolMesh.scale.set(1,r,1);poolMesh.position.set(Math.sin(y)*(d-halfLength),poolY,halfLength+Math.cos(y)*(d-halfLength));
   for(const b of beams){b.mesh.rotation.y=y;b.mesh.scale.set(1,1,r);}
  },
  lamp(kind,index){return (kind==='head'?heads:tails)[index];},
  glows(out,root){
   if(!lit&&!brake)return;root.updateMatrixWorld();
   if(lit)for(const side of headSides)if(side.lamps.some(i=>!(broken&1<<i))){glowAt.copy(side.at).applyMatrix4(root.matrixWorld);out.push({x:glowAt.x,y:glowAt.y,z:glowAt.z,tail:false});}
   for(const side of tailSides)if(side.lamps.some(i=>!(broken&1<<(i+16)))){glowAt.copy(side.at).applyMatrix4(root.matrixWorld);out.push({x:glowAt.x,y:glowAt.y,z:glowAt.z,tail:true});}
  },
  dispose(){poolMesh.removeFromParent();poolGeometry.dispose();poolMaterial.dispose();for(const b of beams)b.mesh.removeFromParent();beamGeometry.dispose();beamMaterial.dispose();for(const m of owned)m.dispose();}};
 return api;
}
