// QA: where the demo's frame time goes. Watch the demo, then take a CDP CPU profile for SECS s: the hottest functions by self
// time (and the share of samples spent idle, i.e. waiting on the GPU or the next frame).
import {chromium} from '@playwright/test';
const port=process.env.PORT??'8795',secs=+(process.env.SECS??10);
const browser=await chromium.launch({channel:'chrome',headless:true,args:['--ignore-gpu-blocklist','--enable-gpu']});
try{const page=await browser.newPage({viewport:{width:1280,height:720}});
 await page.goto(`http://127.0.0.1:${port}/`);await page.waitForSelector('#watch-demo',{timeout:240000});await page.click('#watch-demo');
 await page.waitForFunction(()=>window.__quarry?.state==='playing',null,{timeout:180000});await page.waitForTimeout(4000);
 const cdp=await page.context().newCDPSession(page);await cdp.send('Profiler.enable');await cdp.send('Profiler.setSamplingInterval',{interval:200});await cdp.send('Profiler.start');
 await page.waitForTimeout(secs*1000);const {profile}=await cdp.send('Profiler.stop');
 const byId=new Map(profile.nodes.map(n=>[n.id,n])),self=new Map();let total=0;
 const dt=profile.timeDeltas;for(let i=0;i<profile.samples.length;i++){const n=byId.get(profile.samples[i]);const f=n.callFrame;const key=`${f.functionName||'(anon)'} ${(f.url||'').split('/').pop()}:${f.lineNumber+1}`;self.set(key,(self.get(key)??0)+(dt[i]??0));total+=dt[i]??0;}
 const top=[...self].sort((a,b)=>b[1]-a[1]).slice(0,+(process.env.TOP??35)).map(([k,v])=>[k,+(v/total*100).toFixed(1)]);
 console.log(JSON.stringify({ms:Math.round(total/1000),top}));
}finally{await browser.close();}
