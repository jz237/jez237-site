import {StartReadiness} from './start-readiness';
import {onlineOpponentKinds,isOnlineOpponentSet,type OnlineOpponentSet} from '../src/online-opponents';
import {readNetworkDrives} from '../src/drivetrain/network';
import {validChaseRules} from '../src/online-chase';
import {extendedOnlineCar,ONLINE_CARS,KITE_ONLINE_CARS,MORROW_ONLINE_CARS} from '../src/online-roster';
import {canJoinDerby,canStartDerby} from '../src/online-derby-capability';
import {releaseControls} from './protocol';
import {defaultOnlineEvent,type OnlineEventRules} from '../src/online-events';
import {copyOnlineLivery,validOnlineLivery,validSelectedLivery,type SelectedLivery,type LiveryFrame} from '../src/online-livery';
import type {LiveryLayer} from '../src/livery-data';
import {validOnlineLoadout,copyOnlineSetup,stockOnlineSetup,effectiveOnlineSetup,type SetupRule} from '../src/online-setup';
import {encodeSnapshotWire} from '../src/snapshot-wire';
import {validCapacity} from '../src/online-capacity';
import {newCup,beginCupRound,finishCupRound,nextCupMode,validCup,type CupState,type CupMode} from './cup';
import type Rapier from '@dimforge/rapier3d-compat';
import { Simulation } from './simulation';
import { NEUTRAL, PROTOCOL, parseClientMessage, type Member, type ServerMessage, type Snapshot } from './protocol';
export type Peer = { send(message: ServerMessage): void; close(code: number, reason: string): void; sendEncoded?:(message:string)=>void; sendBinary?:(message:ArrayBuffer)=>void };
type Session = { arenas?:1; courses?:1; roster?:1; kite?:1; morrow?:1; eventRules?:1; timedRace?:1; chase?:1; noRespawnDerby?:1; spinTiers?:1; classEngines?:1; startReady?:1; opponentSets?:1; livery?:SelectedLivery; liveryAt?:number; setupAt?:number; wire?:'qiw1'; cupId:string; voteAt:number; peer: Peer; member: Member; token: string; lastInput: number; seq: number; disconnected: number; rateStart: number; count: number };
export type SavedRoom = { liveries?:LiveryFrame; setupRule?:SetupRule; snapshot: Snapshot; sessions: { arenas?:1; courses?:1; roster?:1; kite?:1; morrow?:1; eventRules?:1; timedRace?:1; chase?:1; noRespawnDerby?:1; spinTiers?:1; classEngines?:1; startReady?:1; opponentSets?:1; livery?:SelectedLivery; wire?:'qiw1'; cupId?:string; member: Member; token: string; disconnected: number; seq: number }[]; updated: number };

export class Room {
  sim: Simulation;
  cup?:CupState;
  setupRule:SetupRule='open';
  opponentSet?:OnlineOpponentSet;
  private startReadiness?:StartReadiness;
  private activeLiveries:LiveryLayer[][]=[];
  private liveryRevision=0;
  sessions = new Map<number, Session>();
  constructor(public code: string, private R: typeof Rapier, public now = () => Date.now()) { this.sim = new Simulation(R,'derby',[],8,[],undefined,0,'angular-v1'); }
  get activeCount() { return [...this.sessions.values()].filter(s=>s.member.connected).length; }
  connect(peer: Peer, raw: string): number | null {
    const hello=parseClientMessage(raw);
    if(!hello||hello.type!=='hello'){peer.close(1008,'Expected valid hello');return null;}
    if(!this.sessions.size&&this.sim.phase==='lobby'&&hello.maxPlayers===24&&this.sim.capacity!==24){this.sim.dispose();this.sim=new Simulation(this.R,'derby',[],24,[],undefined,0,'angular-v1');}
    if(this.sim.capacity===24&&hello.maxPlayers!==24){peer.close(1008,'Update the game to join a 24-driver room.');return null;}
    if(this.sim.event&&!defaultOnlineEvent(this.sim.event.rules)&&hello.eventRules!==1){peer.close(1008,'Update the game to join an event with custom rules.');return null;}
    if(this.startReadiness?.waiting&&hello.startReady!==1){peer.close(1008,'Update the game to join while drivers are loading.');return null;}
    if(this.opponentSet&&hello.opponentSets!==1){peer.close(1008,'Update the game to join a room with selected AI opponents.');return null;}
    const restricted=this.sim.event?.rules.classLimit||this.sim.cars.some(c=>c.state.setup?.engineRestriction)||[...this.sessions.values()].some(s=>s.member.loadout?.setup.engineRestriction);
    if(restricted&&hello.classEngines!==1){peer.close(1008,'Update the game to join class-matched engines.');return null;}
    if(hello.setup?.engineRestriction&&[...this.sessions.values()].some(s=>s.member.connected&&s.classEngines!==1)){peer.close(1008,'All drivers must update before using lower-output engines.');return null;}
    if(this.sim.event?.score&&this.sim.event.combat.feats.graded&&hello.spinTiers!==1){peer.close(1008,'Update the game to join graded spin scoring.');return null;}
    if(this.sim.event?.rules.chase&&hello.chase!==1){peer.close(1008,'Update the game to join Chase.');return null;}
    if(this.sim.event?.rules.raceDuration&&hello.timedRace!==1){peer.close(1008,'Update the game to join timed races.');return null;}
    if(!canJoinDerby(this.sim.event?.rules.derby??'survival',hello)){peer.close(1008,'Update the game to join score derby without respawns.');return null;}
    if(this.sim.event?.rules.arena&&this.sim.event.rules.arena!=='quarry-arena-v1'&&hello.arenas!==1){peer.close(1008,'Update the game to join this arena.');return null;}
    if(this.sim.event?.rules.course&&this.sim.event.rules.course!=='quarry-v1'&&hello.courses!==1){peer.close(1008,'Update the game to join this course.');return null;}
    const extended=this.sim.cars.some(c=>extendedOnlineCar(c.state.kind))||[...this.sessions.values()].some(s=>extendedOnlineCar(s.member.kind)||extendedOnlineCar(s.member.loadout?.kind));
    if(hello.roster!==1&&extended){peer.close(1008,'Update the game to join a full-roster room.');return null;}
    if(extendedOnlineCar(hello.kind)&&[...this.sessions.values()].some(s=>s.member.connected&&s.roster!==1)){peer.close(1008,'All connected drivers must update before selecting newer cars.');return null;}
    const hasKite=this.sim.cars.some(c=>c.state.kind==='kite')||[...this.sessions.values()].some(s=>s.member.kind==='kite'||s.member.loadout?.kind==='kite');
    const hasMorrow=this.sim.cars.some(c=>c.state.kind==='morrow')||[...this.sessions.values()].some(s=>s.member.kind==='morrow'||s.member.loadout?.kind==='morrow');
    if(hello.kite!==1&&hasKite){peer.close(1008,'Update the game to join a Kite room.');return null;}
    if(hello.morrow!==1&&hasMorrow){peer.close(1008,'Update the game to join a Morrow room.');return null;}
    if(hello.kind==='kite'&&[...this.sessions.values()].some(s=>s.member.connected&&s.kite!==1)){peer.close(1008,'All connected drivers must update before selecting the Kite.');return null;}
    if(hello.kind==='morrow'&&[...this.sessions.values()].some(s=>s.member.connected&&s.morrow!==1)){peer.close(1008,'All connected drivers must update before selecting the Morrow.');return null;}
    let session=hello.token?[...this.sessions.values()].find(s=>s.token===hello.token):undefined;
    if(session){
      if(session.member.connected)session.peer.close(4001,'Reconnected elsewhere');
      session.peer=peer;session.member.connected=true;session.disconnected=0;session.lastInput=this.now();session.rateStart=this.now();session.count=0;
    }else{
      const id=Array.from({length:this.sim.capacity},(_,i)=>i).find(i=>!this.sessions.has(i)||(!this.sessions.get(i)!.member.connected&&this.now()-this.sessions.get(i)!.disconnected>60_000));
      if(id===undefined){peer.close(4004,'Room is full');return null;}
      // Mid-event entrants take over the existing AI car, preserving its condition and location.
      session={cupId:crypto.randomUUID(),voteAt:-Infinity,peer,member:{id,loadout:{kind:hello.kind,setup:hello.setup??stockOnlineSetup(hello.kind)},name:hello.name,kind:this.sim.phase==='lobby'||this.sim.phase==='result'?hello.kind:this.sim.cars[id].state.kind,connected:true,host:this.sessions.size===0},token:crypto.randomUUID(),lastInput:this.now(),seq:-1,disconnected:0,rateStart:this.now(),count:0};
      this.sessions.set(id,session);
    }
    session.arenas=hello.arenas;session.courses=hello.courses;session.roster=hello.roster;session.kite=hello.kite;session.morrow=hello.morrow;session.wire=hello.wire;session.eventRules=hello.eventRules;session.timedRace=hello.timedRace;session.chase=hello.chase;session.noRespawnDerby=hello.noRespawnDerby;session.spinTiers=hello.spinTiers;session.classEngines=hello.classEngines;session.opponentSets=hello.opponentSets;session.startReady=hello.startReady;
    this.electHost();
    const welcome:ServerMessage={type:'welcome',protocol:PROTOCOL,room:this.code,id:session.member.id,token:session.token,snapshot:this.snapshot(true),liveries:this.liveryFrame(),...(session.livery?{pendingLivery:structuredClone(session.livery)}:{})};
    if(session.wire&&peer.sendBinary)peer.sendBinary(encodeSnapshotWire(welcome));else peer.send(welcome);
    this.broadcast();return session.member.id;
  }
  receive(id:number,peer:Peer,raw:string){
    const s=this.sessions.get(id);if(!s||s.peer!==peer||!s.member.connected)return;
    if(this.now()-s.rateStart>=1000){s.rateStart=this.now();s.count=0;}
    if(++s.count>90){peer.close(1008,'Input rate exceeded');this.disconnect(id,peer);return;}
    const m=parseClientMessage(raw);if(!m){peer.close(1008,'Invalid message');this.disconnect(id,peer);return;}
    if(m.type==='start-ready'){if(s.startReady===1&&this.sim.phase==='countdown'&&this.startReadiness?.acknowledge(id,m.round)){this.broadcast();return true;}return;}
    if((m.type==='setup'||m.type==='livery')&&extendedOnlineCar(m.kind)&&(s.roster!==1||[...this.sessions.values()].some(p=>p.member.connected&&p.roster!==1))){peer.send({type:'error',message:'All connected drivers must update before selecting newer cars.'});return;}
    if((m.type==='setup'||m.type==='livery')&&m.kind==='kite'&&(s.kite!==1||[...this.sessions.values()].some(p=>p.member.connected&&p.kite!==1))){peer.send({type:'error',message:'All connected drivers must update before selecting the Kite.'});return;}
    if((m.type==='setup'||m.type==='livery')&&m.kind==='morrow'&&(s.morrow!==1||[...this.sessions.values()].some(p=>p.member.connected&&p.morrow!==1))){peer.send({type:'error',message:'All connected drivers must update before selecting the Morrow.'});return;}
    if(m.type==='setup'&&m.setup.engineRestriction&&(s.classEngines!==1||[...this.sessions.values()].some(p=>p.member.connected&&p.classEngines!==1))){peer.send({type:'error',message:'All drivers must update before using lower-output engines.'});return;}
    if(m.type==='opponent-set'){
      if(!s.member.host){peer.send({type:'error',message:'Only the host can choose AI opponents.'});return;}
      if(this.sim.phase!=='lobby'&&this.sim.phase!=='result'){peer.send({type:'error',message:'Change AI opponents between events.'});return;}
      if([...this.sessions.values()].some(p=>p.member.connected&&p.opponentSets!==1)){peer.send({type:'error',message:'All drivers must update before changing AI opponents.'});return;}
      if(this.now()-(s.setupAt??-Infinity)<250){peer.send({type:'error',message:'Wait a moment before changing the field again.'});return;}s.setupAt=this.now();
      this.opponentSet=m.set==='auto'?undefined:m.set;this.refreshLobbyOpponents();this.broadcast();return true;
    }
    if(m.type==='livery'){
      if(m.kind!==s.member.loadout?.kind){peer.send({type:'error',message:'Choose the matching car before applying its design.'});return;}
      if(this.now()-(s.liveryAt??-Infinity)<1000){peer.send({type:'error',message:'Wait a moment before applying another design.'});return;}
      s.liveryAt=this.now();s.livery={kind:m.kind,layers:copyOnlineLivery(m.layers)};s.member.liveryLayers=m.layers.length;this.broadcast();return true;
    }
    if(m.type==='setup'||m.type==='setup-rule'){
      if(this.sim.phase!=='lobby'&&this.sim.phase!=='result'){peer.send({type:'error',message:'Change your setup between events.'});return;}
      if(m.type==='setup-rule'&&!s.member.host){peer.send({type:'error',message:'Only the host can set performance rules.'});return;}
      if(this.now()-(s.setupAt??-Infinity)<250){peer.send({type:'error',message:'Wait a moment before changing your setup again.'});return;}s.setupAt=this.now();
      if(m.type==='setup-rule')this.setupRule=m.rule;else{if(s.member.loadout?.kind!==m.kind){s.livery=undefined;s.member.liveryLayers=0;}s.member.loadout={kind:m.kind,setup:copyOnlineSetup(m.setup)};s.member.kind=m.kind;}
      this.broadcast();return true;
    }
    if(m.type==='input'){
      if(m.seq<=s.seq)return;s.seq=m.seq;s.lastInput=this.now();this.sim.setInput(id,m.controls);
    }else if(m.type==='start'){
      if(!s.member.host){peer.send({type:'error',message:'Only the room host can start an event.'});return;}
      if(this.sim.phase!=='lobby'&&this.sim.phase!=='result'){peer.send({type:'error',message:'The event is already running.'});return;}
      if(this.cup&&this.cup.completed<this.cup.rounds){peer.send({type:'error',message:'Continue the current cup using Next round.'});return;}
      if(m.rules&&!defaultOnlineEvent(m.rules)&&[...this.sessions.values()].some(s=>s.member.connected&&s.eventRules!==1)){peer.send({type:'error',message:'All drivers must update the game before using custom event rules.'});return;}
      if(!canStartDerby(m.rules?.derby??this.sim.event?.rules.derby??'survival',true,[...this.sessions.values()].map(p=>({...p,connected:p.member.connected})))){peer.send({type:'error',message:'All connected drivers must update before starting score derby without respawns.'});return;}
      if((m.rules??this.sim.event?.rules)?.raceDuration&&[...this.sessions.values()].some(p=>p.member.connected&&p.timedRace!==1)){peer.send({type:'error',message:'All connected drivers must update before starting timed races.'});return;}
      if((m.rules??this.sim.event?.rules)?.arena&&(m.rules??this.sim.event?.rules)?.arena!=='quarry-arena-v1'&&[...this.sessions.values()].some(p=>p.member.connected&&p.arenas!==1)){peer.send({type:'error',message:'All connected drivers must update before using other arenas.'});return;}
      if((m.rules??this.sim.event?.rules)?.course&&(m.rules??this.sim.event?.rules)?.course!=='quarry-v1'&&[...this.sessions.values()].some(p=>p.member.connected&&p.courses!==1)){peer.send({type:'error',message:'All connected drivers must update before using other courses.'});return;}
      let rules=m.rules??this.sim.event?.rules;
      if(rules?.classLimit&&[...this.sessions.values()].some(p=>p.member.connected&&p.classEngines!==1)){peer.send({type:'error',message:'All drivers must update before starting a class-limited event.'});return;}
      if(!m.rules&&m.mode!=='race'&&rules?.chase){const {chase,...ordinary}=rules;rules=ordinary;}
      if(rules?.chase){
        if(m.mode!=='race'||!validChaseRules(rules.chase,this.sim.capacity)){peer.send({type:'error',message:'Chase needs a circuit race and valid runner slots for this room.'});return;}
        if((m.rounds??1)>1){peer.send({type:'error',message:'Chase is a single team event; choose one round.'});return;}
        if([...this.sessions.values()].some(p=>p.member.connected&&p.chase!==1)){peer.send({type:'error',message:'All connected drivers must update before starting Chase.'});return;}
      }
      this.cup=(m.rounds??1)>1?newCup(m.rounds!,m.mode as CupMode):undefined;
      this.startRound(m.mode,rules);this.broadcast();return true;
    }else if(m.type==='vote'){
      if(!this.cup||this.sim.phase!=='result'||this.cup.completed>=this.cup.rounds){peer.send({type:'error',message:'Voting opens between cup rounds.'});return;}
      if(this.cup.votes[id]===m.mode||this.now()-s.voteAt<250)return;
      s.voteAt=this.now();this.cup.votes[id]=m.mode;this.broadcast();return true;
    }else if(m.type==='next'){
      if(!s.member.host){peer.send({type:'error',message:'Only the room host can advance the cup.'});return;}
      if(!this.cup||this.sim.phase!=='result'||this.cup.completed>=this.cup.rounds){peer.send({type:'error',message:'There is no next cup round.'});return;}
      this.startRound(nextCupMode(this.cup,new Set([...this.sessions].filter(([,s])=>s.member.connected).map(([id])=>id))));this.broadcast();return true;
    }else if(m.type==='recover'){if(this.sim.recover(id))this.broadcast();}
    else if(m.type==='ping')peer.send({type:'pong',sent:m.sent});
  }
  disconnect(id:number,peer:Peer){const s=this.sessions.get(id);if(!s||s.peer!==peer)return;s.member.connected=false;s.disconnected=this.now();if(this.cup)delete this.cup.votes[id];this.sim.setInput(id,{...NEUTRAL});this.electHost();this.broadcast();}
  private electHost(){let host=[...this.sessions.values()].find(s=>s.member.connected&&s.member.host);host??=[...this.sessions.values()].find(s=>s.member.connected);for(const s of this.sessions.values())s.member.host=s===host;}
  step(){const human=new Set<number>();for(const [id,s]of this.sessions){if(s.member.connected){human.add(id);if(this.now()-s.lastInput>350)this.sim.setInput(id,releaseControls(this.sim.cars[id].state.input));}}if(this.startReadiness?.waiting&&this.sim.phase==='countdown'){this.startReadiness.advance(1000/60,human);return;}this.sim.step(human);this.settleCup();}
  snapshot(includeDamage=false):Snapshot{this.settleCup();return {...this.sim.snapshot(includeDamage),startReadySupport:true,...(this.startReadiness?.waiting&&this.sim.phase==='countdown'?{startReadiness:this.startReadiness.snapshot()}:{}),...(this.opponentSet?{opponentSet:this.opponentSet}:{}),...([...this.sessions.values()].filter(s=>s.member.connected).every(s=>s.opponentSets===1)?{opponentSetSupport:true as const}:{}),arenaSupport:true,courseSupport:true,rosterSupport:true,...([...this.sessions.values()].filter(s=>s.member.connected).every(s=>s.kite===1)?{kiteSupport:true as const}:{}),...([...this.sessions.values()].filter(s=>s.member.connected).every(s=>s.morrow===1&&s.kite===1)?{morrowSupport:true as const}:{}),transmissionSupport:true,assistsSupport:true,absSupport:true,eventSupport:true,timedRaceSupport:true,...([...this.sessions.values()].filter(s=>s.member.connected).every(s=>s.chase===1)?{chaseSupport:true as const}:{}),noRespawnDerbySupport:true,...([...this.sessions.values()].filter(s=>s.member.connected).every(s=>s.classEngines===1)?{classEngineSupport:true as const}:{}),...([...this.sessions.values()].filter(s=>s.member.connected).every(s=>s.spinTiers===1)?{spinTierSupport:true as const}:{}),liverySupport:true,liveryRevision:this.liveryRevision,setupSupport:true,setupRule:this.setupRule,cupSupport:true,...(this.cup?{cup:structuredClone(this.cup)}:{}),members:[...this.sessions.values()].map(s=>({...structuredClone(s.member),cupId:s.cupId})),ack:Object.fromEntries([...this.sessions].map(([id,s])=>[id,s.seq]))};}
  broadcast(){const snap=this.snapshot();let encoded:string|undefined,binary:ArrayBuffer|undefined;for(const s of this.sessions.values())if(s.member.connected)try{if(s.wire&&s.peer.sendBinary)s.peer.sendBinary(binary??=encodeSnapshotWire(snap));else if(s.peer.sendEncoded)s.peer.sendEncoded(encoded??=JSON.stringify(snap));else s.peer.send(snap);}catch{s.member.connected=false;s.disconnected=this.now();}this.electHost();}
  save():SavedRoom{return{liveries:this.liveryFrame(),setupRule:this.setupRule,snapshot:this.snapshot(true),sessions:[...this.sessions.values()].map(s=>({...s.arenas===1?{arenas:1 as const}:{},...s.courses===1?{courses:1 as const}:{},...s.roster===1?{roster:1 as const}:{},...s.kite===1?{kite:1 as const}:{},...s.morrow===1?{morrow:1 as const}:{},...s.eventRules?{eventRules:s.eventRules}:{},...s.chase===1?{chase:1 as const}:{},...s.timedRace===1?{timedRace:1 as const}:{},...s.startReady===1?{startReady:1 as const}:{},...s.opponentSets===1?{opponentSets:1 as const}:{},...s.classEngines===1?{classEngines:1 as const}:{},...s.spinTiers===1?{spinTiers:1 as const}:{},...s.noRespawnDerby===1?{noRespawnDerby:1 as const}:{},...s.livery?{livery:structuredClone(s.livery)}:{},...s.wire?{wire:s.wire}:{},cupId:s.cupId,member:structuredClone(s.member),token:s.token,disconnected:s.disconnected,seq:s.seq})),updated:this.now()};}
  restore(saved:SavedRoom){if(saved.snapshot.startReadiness&&(saved.snapshot.phase!=='countdown'||saved.snapshot.countdown!==3||saved.snapshot.tick!==0||saved.snapshot.elapsed!==0))throw Error('Invalid saved readiness phase');this.startReadiness=saved.snapshot.startReadiness?StartReadiness.restore(saved.snapshot.startReadiness):undefined;if(saved.snapshot.opponentSet!==undefined&&!isOnlineOpponentSet(saved.snapshot.opponentSet))throw Error('Invalid saved opponent set');this.opponentSet=saved.snapshot.opponentSet;readNetworkDrives(saved.snapshot);this.liveryRevision=Number.isSafeInteger(saved.liveries?.revision)&&saved.liveries!.revision>=0?saved.liveries!.revision:0;this.activeLiveries=saved.snapshot.cars.map(c=>{const row=saved.liveries?.cars.find(v=>v.id===c.id&&v.kind===c.kind);return row&&validOnlineLivery(row.layers)?copyOnlineLivery(row.layers):[];});this.setupRule=saved.setupRule==='stock'?'stock':'open';this.sim.dispose();const capacity=saved.snapshot.capacity??saved.snapshot.cars.length;if(!validCapacity(capacity)||capacity!==saved.snapshot.cars.length)throw new Error('Invalid saved room capacity');this.sim=new Simulation(this.R,saved.snapshot.mode,saved.snapshot.cars.map(c=>c.kind),capacity,saved.snapshot.cars.map(c=>c.setup),saved.snapshot.event?.rules,saved.snapshot.event?.seed);this.sim.restore(saved.snapshot);this.cup=validCup(saved.snapshot.cup)?structuredClone(saved.snapshot.cup):undefined;this.sessions.clear();for(const s of saved.sessions)this.sessions.set(s.member.id,{...s,livery:validSelectedLivery(s.livery)?structuredClone(s.livery):undefined,cupId:s.cupId??crypto.randomUUID(),voteAt:-Infinity,member:{...structuredClone(s.member),...(validOnlineLoadout(s.member.loadout)?{}:{loadout:{kind:s.member.kind,setup:stockOnlineSetup(s.member.kind)}}),connected:false},peer:{send(){},close(){}},lastInput:0,rateStart:0,count:0,disconnected:s.disconnected||this.now()});}
  private refreshLobbyOpponents(){
    if(this.sim.phase!=='lobby')return;
    const kinds=onlineOpponentKinds(this.sim.cars.map(c=>c.kind),this.sim.cars.map((c,i)=>this.sessions.has(i)?c.kind:undefined),MORROW_ONLINE_CARS,this.opponentSet);
    let changed=false;for(const [id,kind]of kinds.entries())if(this.sim.replaceLobbyCar(id,kind)){this.activeLiveries[id]=[];changed=true;}
    if(changed){this.liveryRevision++;const message:ServerMessage={type:'liveries',frame:this.liveryFrame()};for(const session of this.sessions.values())if(session.member.connected)session.peer.send(message);}
  }
  private startRound(mode:'race'|'derby'|'playground',rules:OnlineEventRules|undefined=this.sim.event?.rules){
    if(this.cup)beginCupRound(this.cup,mode as CupMode,Array.from({length:this.sim.capacity},(_,id)=>{const session=this.sessions.get(id);return session?.member.connected?{id:session.cupId,name:session.member.name,bot:false}:{id:'bot-'+id,name:'AI DRIVER '+(id+1),bot:true};}));
    const loadouts=Array.from({length:this.sim.capacity},(_,i)=>this.sessions.get(i)?.member.loadout);
    const fullRoster=[...this.sessions.values()].filter(s=>s.member.connected).every(s=>s.roster===1);
    const roster=[...this.sessions.values()].filter(s=>s.member.connected).every(s=>s.morrow===1&&s.kite===1)?MORROW_ONLINE_CARS:[...this.sessions.values()].filter(s=>s.member.connected).every(s=>s.kite===1)?KITE_ONLINE_CARS:ONLINE_CARS;
    const kinds=onlineOpponentKinds(this.sim.cars.map(c=>c.state.kind),loadouts.map((loadout,i)=>loadout?.kind??this.sessions.get(i)?.member.kind),fullRoster?roster:undefined,this.opponentSet);
    const setups=loadouts.map((loadout,i)=>effectiveOnlineSetup(kinds[i],loadout?.setup??stockOnlineSetup(kinds[i]),this.setupRule));
    this.activeLiveries=kinds.map((kind,i)=>{const selection=this.sessions.get(i)?.livery;return selection?.kind===kind?copyOnlineLivery(selection.layers):[];});this.liveryRevision++;
    for(const [i,session]of this.sessions)session.member.kind=kinds[i];
    const capacity=this.sim.capacity;this.sim.dispose();this.sim=new Simulation(this.R,mode,kinds,capacity,setups,rules,rules?crypto.getRandomValues(new Uint32Array(1))[0]:0,'angular-v1',[...this.sessions.values()].filter(s=>s.member.connected).every(s=>s.spinTiers===1));this.sim.start();
    const participants=[...this.sessions.values()].filter(s=>s.member.connected);this.startReadiness=participants.length&&participants.every(s=>s.startReady===1)?new StartReadiness(crypto.randomUUID(),participants.map(s=>s.member.id)):undefined;
    const message:ServerMessage={type:'liveries',frame:this.liveryFrame()};let binary:ArrayBuffer|undefined,encoded:string|undefined;for(const session of this.sessions.values())if(session.member.connected){try{if(session.wire&&session.peer.sendBinary)session.peer.sendBinary(binary??=encodeSnapshotWire(message));else if(session.peer.sendEncoded)session.peer.sendEncoded(encoded??=JSON.stringify(message));else session.peer.send(message);}catch{session.member.connected=false;session.disconnected=this.now();}}
    for(const session of this.sessions.values()){session.lastInput=0;session.voteAt=-Infinity;}
  }
  private liveryFrame():LiveryFrame{return{revision:this.liveryRevision,cars:this.sim.cars.map(c=>({id:c.state.id,kind:c.state.kind,layers:copyOnlineLivery(this.activeLiveries[c.state.id]??[])}))};}
  private settleCup(){
    if(!this.cup||this.sim.phase!=='result'||this.cup.completed===this.cup.round)return;
    const eligible=new Set(this.cup.entries.filter(e=>e.bot).map(e=>e.id));
    for(const [slot,session]of this.sessions)if(session.member.connected&&this.cup.participants[slot]===session.cupId)eligible.add(session.cupId);
    finishCupRound(this.cup,this.sim.ranking(),eligible);
  }
  dispose(){this.sim.dispose();}
}
