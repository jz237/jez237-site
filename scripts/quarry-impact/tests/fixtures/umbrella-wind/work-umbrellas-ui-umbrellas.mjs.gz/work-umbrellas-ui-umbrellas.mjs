// QA: umbrellas. A four-car derby in the rain: the stands must hold umbrellas (__quarry.umbrellas() > 0), shown looking
// up at a grandstand; a dry (midday) derby must have none up. Reports page errors.
import {chromium} from '@playwright/test';
const port=process.env.PORT??'8795',out=new URL('.',import.meta.url).pathname;
const run=async(lighting,shots)=>{const browser=await chromium.launch({channel:'chrome',headless:true,args:['--ignore-gpu-blocklist','--enable-gpu']});const errors=[];
 try{const page=await browser.newPage({viewport:{width:1280,height:720}});page.on('pageerror',e=>errors.push(e.message.slice(0,160)));page.on('console',m=>{if(m.type()==='error')errors.push(m.text().slice(0,160));});
  await page.goto(`http://127.0.0.1:${port}/`);await page.waitForSelector('#start',{timeout:240000});
  await page.evaluate(l=>{const o=JSON.parse(localStorage.getItem('quarry-impact-events-v1')??'{"version":1}');Object.assign(o,{version:1,field:4,arena:'harrow-bowl-v1',derby:'survival',duration:180});localStorage.setItem('quarry-impact-events-v1',JSON.stringify(o));
   const s=JSON.parse(localStorage.getItem('quarry-impact-v1')??'{}');s.lighting=l;localStorage.setItem('quarry-impact-v1',JSON.stringify(s));},lighting);
  await page.reload();await page.waitForSelector('#start',{timeout:240000});await page.click('.mode-card[data-mode="derby"]');await page.click('#start');
  await page.waitForFunction(()=>window.__quarry?.state==='playing',null,{timeout:180000});await page.waitForTimeout(1500);
  const result={lighting,umbrellas:await page.evaluate(()=>__quarry.umbrellas())};
  if(shots){await page.screenshot({path:out+'rain-stands.jpg',quality:88});
   await page.evaluate(()=>{const c=__quarry.inspect()[0],[x,y,z]=c.position,[fx,,fz]=c.forward;__quarry.captureCamera([x+fx*44,y+4.5,z+fz*44],[x+fx*66,y+5,z+fz*66]);});await page.waitForTimeout(600);
   await page.screenshot({path:out+'rain-stands-close.jpg',quality:88});await page.evaluate(()=>__quarry.resume());}
  result.errors=errors.slice(0,3);return result;
 }finally{await browser.close();}};
console.log(JSON.stringify(await run('rain',true)));
console.log(JSON.stringify(await run('midday',false)));
