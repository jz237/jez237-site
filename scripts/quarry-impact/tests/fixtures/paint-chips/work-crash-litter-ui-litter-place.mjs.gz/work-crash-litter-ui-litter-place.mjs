// QA: crash litter renders where it lands. Four-car derby, rivals moved away; glass, headlamp and tail lamp litter is scattered
// on the floor 4-6 m ahead of the parked player and photographed from just above (work/crash-litter/placed.jpg).
import {chromium} from '@playwright/test';
const port=process.env.PORT??'8795';
const browser=await chromium.launch({channel:'chrome',headless:true,args:['--ignore-gpu-blocklist','--enable-gpu']});const errors=[];
try{const page=await browser.newPage({viewport:{width:1280,height:720}});page.on('pageerror',e=>errors.push(e.message.slice(0,160)));page.on('console',m=>{if(m.type()==='error')errors.push(m.text().slice(0,160));});
 await page.goto(`http://127.0.0.1:${port}/`);await page.waitForSelector('#start',{timeout:240000});
 await page.evaluate(()=>{const o=JSON.parse(localStorage.getItem('quarry-impact-events-v1')??'{"version":1}');Object.assign(o,{version:1,field:4,arena:'harrow-bowl-v1',derby:'survival',duration:180});localStorage.setItem('quarry-impact-events-v1',JSON.stringify(o));});
 await page.reload();await page.waitForSelector('#start',{timeout:240000});await page.click('.mode-card[data-mode="derby"]');await page.click('#start');
 await page.waitForFunction(()=>window.__quarry?.state==='playing',null,{timeout:180000});await page.evaluate(()=>__quarry.mute?.());await page.waitForTimeout(800);
 const r=await page.evaluate(()=>{const [px,py,pz]=__quarry.inspect()[0].position,[fx,,fz]=__quarry.inspect()[0].forward;for(const i of [1,2,3]){__quarry.setEngineDamage(i,1);__quarry.teleport(i,px+60*(i-2),pz+60,0);}
  const at=d=>[px+fx*d,py+.9,pz+fz*d];__quarry.scatterLitter(at(4),'glass',3);__quarry.scatterLitter(at(5.2),'head',4);__quarry.scatterLitter(at(6.2),'tail',5);
  return {litter:__quarry.litter(),player:[px,py,pz],fwd:[fx,fz]};});
 await page.waitForTimeout(400);
 await page.evaluate(({player:[px,py,pz],fwd:[fx,fz]})=>{if(__quarry.state==='paused')__quarry.resume();__quarry.captureCamera([px+fx*2.4,py+1.9,pz+fz*2.4],[px+fx*5,py,pz+fz*5]);document.querySelectorAll('.hud,.overlay,.toast,#overlay').forEach(e=>e.style.display='none');},r);
 await page.waitForTimeout(450);await page.screenshot({path:'work/crash-litter/placed.jpg',quality:92});
 console.log(JSON.stringify({...r,errors:errors.slice(0,3)}));
}finally{await browser.close();}
