// QA: marshals. A four-car derby: four marshals stand round the arena (__quarry.marshals()), waving green as the heat
// starts, then flags down; a rival wrecked beside a post brings out its yellow flag. Shot close. Reports page errors.
import {chromium} from '@playwright/test';
const port=process.env.PORT??'8795',out=new URL('.',import.meta.url).pathname;
const browser=await chromium.launch({channel:'chrome',headless:true,args:['--ignore-gpu-blocklist','--enable-gpu']});const errors=[];
try{const page=await browser.newPage({viewport:{width:1280,height:720}});page.on('pageerror',e=>errors.push(e.message.slice(0,160)));page.on('console',m=>{if(m.type()==='error')errors.push(m.text().slice(0,160));});
 await page.goto(`http://127.0.0.1:${port}/`);await page.waitForSelector('#start',{timeout:240000});
 await page.evaluate(()=>{const o=JSON.parse(localStorage.getItem('quarry-impact-events-v1')??'{"version":1}');Object.assign(o,{version:1,field:4,arena:'harrow-bowl-v1',derby:'survival',duration:180});localStorage.setItem('quarry-impact-events-v1',JSON.stringify(o));const s=JSON.parse(localStorage.getItem('quarry-impact-v1')??'{}');s.lighting='midday';localStorage.setItem('quarry-impact-v1',JSON.stringify(s));});
 await page.reload();await page.waitForSelector('#start',{timeout:240000});await page.click('.mode-card[data-mode="derby"]');await page.click('#start');
 await page.waitForFunction(()=>window.__quarry?.state==='playing',null,{timeout:180000});await page.waitForTimeout(300);
 const start=await page.evaluate(()=>__quarry.marshals());await page.waitForTimeout(4500);const later=await page.evaluate(()=>__quarry.marshals().map(m=>m.flag));
 const post=start[0].at;await page.evaluate(p=>{__quarry.teleport(1,p[0]*.8,p[2]*.8,0);__quarry.setHealth(1,0);},post);await page.waitForTimeout(600);
 const wreck=await page.evaluate(()=>__quarry.marshals().map(m=>m.flag));const rival=await page.evaluate(()=>{const c=__quarry.inspect()[1];return {pos:c.position.map(v=>+v.toFixed(1)),health:c.health};});
 await page.evaluate(p=>{__quarry.captureCamera([p[0]*.82,p[1]+2.2,p[2]*.82],[p[0],p[1]+1.2,p[2]]);},post);await page.waitForTimeout(500);await page.screenshot({path:out+'marshal-yellow.jpg',quality:88});await page.evaluate(()=>__quarry.resume());
 console.log(JSON.stringify({start,later,wreck,rival,errors:errors.slice(0,3)}));
}finally{await browser.close();}
