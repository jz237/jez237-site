import * as T from 'three';
import {finishVehiclePresentation} from './vehicle-presentation';
import {LAMP_GRIME,WAKE} from './wake-dust';
import {TOP_DUST} from './settled-dust';
import {RUST,rusts,type RustFit} from './age-rust';

/** Persistent deposition state. Four tires retain water after leaving a puddle. */
export class VehicleSurface {
  readonly coating={value:new T.Vector4(0,0,0,0)}; // left/right wetness, left/right dirt
  readonly water=new Float32Array(4);
  /** Wake dust on the tail (offline): x the back of the bodywork along the car (model frame), y how far forward it reaches
   * (0 until placed), z how dusty. */
  readonly wake={value:new T.Vector4(0,0,0,0)};
  /** Age rust (offline, RUST): x how far gone (0 none), y the foot of the flanks, z the half width, w the front arch's edge
   * (radius); arches x/y the front and rear axle along the car, z the hub height, w the rear arch's edge (model frame). */
  readonly rust={value:new T.Vector4(0,0,0,0)};
  readonly arches={value:new T.Vector4(0,0,0,0)};
  readonly phase:{value:number};
  distance=0;
  constructor(root:T.Group,id:number){
    this.phase={value:id*.731};finishVehiclePresentation(root);
    const seen=new Set<T.Material>();
    root.traverse(o=>{
      if(!(o instanceof T.Mesh)||!o.userData.wreckRest)return;
      const m=o.material as T.MeshPhysicalMaterial;if(seen.has(m))return;seen.add(m);
      const painted=m.name.startsWith('paint'),glass=o.name.startsWith('glass_'),plastic=/Paint 2|hoses|Interior|Panel Sides/.test(m.name);
      if(painted){const enamel=/^paint_(Marten|Tern|Carrier|Ravine)$/.test(m.name);m.metalness=plastic?.06:enamel?.12:.23;m.roughness=plastic?.4:enamel?.36:.26;m.clearcoat=plastic?.3:enamel?.85:.96;m.clearcoatRoughness=enamel?.18:.13;m.normalScale.setScalar(.025);m.envMapIntensity=.88;}
      if(glass){m.metalness=.025;m.ior=1.52;m.roughness=.052;m.envMapIntensity=.95;}
      if(m.name.includes('galvanized steel')){m.metalness=.85;m.roughness=.46;}
      if(m.name.includes('cast alloy')){m.metalness=.72;m.roughness=.53;}
      if(m.name.includes('hoses')){m.metalness=0;m.roughness=.87;}
      const base=m.onBeforeCompile,key=m.customProgramCacheKey();
      m.onBeforeCompile=(s,renderer)=>{
        base.call(m,s,renderer);s.uniforms.carCoating=this.coating;s.uniforms.carSurfacePhase=this.phase;s.uniforms.carWake=this.wake;s.uniforms.carTopDust=TOP_DUST;s.uniforms.carRust=this.rust;s.uniforms.carArches=this.arches;
        s.vertexShader=s.vertexShader.replace('#include <common>','#include <common>\nattribute vec4 transferPaint;varying vec4 vTransferredPaint;varying vec3 vCoatingRest;'+(s.vertexShader.includes('attribute vec3 wreckPosition;')?'':'\nattribute vec3 wreckPosition;'))
          .replace('#include <begin_vertex>','#include <begin_vertex>\nvCoatingRest=wreckPosition;vTransferredPaint=transferPaint;');
        s.fragmentShader=s.fragmentShader.replace('#include <common>',`#include <common>
varying vec4 vTransferredPaint;varying vec3 vCoatingRest;uniform vec4 carCoating;uniform float carSurfacePhase;uniform vec4 carWake;uniform float carTopDust;uniform vec4 carRust;uniform vec4 carArches;
float coatingHash(vec3 p){return fract(sin(dot(p,vec3(127.1,311.7,74.7)))*43758.5453);}
float coatingNoise(vec3 p){vec3 c=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(mix(coatingHash(c),coatingHash(c+vec3(1,0,0)),f.x),mix(coatingHash(c+vec3(0,1,0)),coatingHash(c+vec3(1,1,0)),f.x),f.y),mix(mix(coatingHash(c+vec3(0,0,1)),coatingHash(c+vec3(1,0,1)),f.x),mix(coatingHash(c+vec3(0,1,1)),coatingHash(c+vec3(1,1,1)),f.x),f.y),f.z);}
`)
          .replace(/float dust=clamp\(lowBody\*\([^;]+;/,'float dust=clamp(lowBody*.035+vImpactWear.x*.07,0.,.32);')
          .replace('#include <alphamap_fragment>',`#include <alphamap_fragment>
float ageRust=0.,rustStain=0.;
${rusts(m.name)?`// Age rust: rot along the sills and round the arch lips, mottled, with a stained fringe of blistered paint.
if(carRust.x>0.){
  float rustFlank=smoothstep(carRust.z*${RUST.flank[0]},carRust.z*${RUST.flank[1]},abs(vCoatingRest.x));
  // Patches creep up the sills to their own heights, and the lips rot worst at their low ends, by the hub.
  float rustReach=coatingNoise(vCoatingRest*vec3(4.,4.,7.)+carSurfacePhase*11.);
  float rustSill=1.-smoothstep(carRust.y+${RUST.sill[0]},carRust.y+${RUST.sill[1]}*(.35+.9*rustReach),vCoatingRest.y);
  float frontLip=length(vec2(vCoatingRest.z-carArches.x,vCoatingRest.y-carArches.z))-carRust.w-${RUST.gap},rearLip=length(vec2(vCoatingRest.z-carArches.y,vCoatingRest.y-carArches.z))-carArches.w-${RUST.gap};
  float rustLip=max(exp(-pow(frontLip/${RUST.lip},2.)),exp(-pow(rearLip/${RUST.lip},2.)))*smoothstep(carArches.z-.12,carArches.z+.02,vCoatingRest.y)*(.55+.45*smoothstep(carArches.z+.3,carArches.z,vCoatingRest.y));
  float rustNoise=coatingNoise(vCoatingRest*vec3(11.,17.,11.)+carSurfacePhase*7.)*.6+coatingNoise(vCoatingRest*vec3(46.,60.,46.))*.4;
  float rustField=max(rustSill,rustLip)*rustFlank*(.2+1.05*rustNoise),rustEdge=1.-.7*carRust.x;
  ageRust=smoothstep(rustEdge-.06,rustEdge+.06,rustField);
  rustStain=smoothstep(rustEdge-.22,rustEdge-.06,rustField)*(1.-ageRust);
  diffuseColor.rgb=mix(diffuseColor.rgb,diffuseColor.rgb*vec3(${RUST.stain}),rustStain*.7);
  diffuseColor.rgb=mix(diffuseColor.rgb,mix(vec3(${RUST.orange}),vec3(${RUST.scale}),coatingNoise(vCoatingRest*95.)),ageRust);
}`:''}
float coatingSide=smoothstep(-.3,.3,vCoatingRest.x);
float deposited=mix(carCoating.z,carCoating.w,coatingSide);
float moisture=mix(carCoating.x,carCoating.y,coatingSide);
float coatingLow=1.-smoothstep(.32,1.28,vCoatingRest.y);
float thrown=exp(-pow((abs(vCoatingRest.z)-1.45)*2.7,2.));
float siltPattern=coatingNoise(vCoatingRest*vec3(26.,40.,22.)+carSurfacePhase)*.58+coatingNoise(vCoatingRest*7.)*.42;
float carDirt=clamp(deposited*(coatingLow*.74+thrown*.38)*(.45+siltPattern),0.,.72);
float carWet=clamp(moisture*(coatingLow*.8+thrown*.3),0.,1.);
// Wake dust: a film over the tail, thickest at the very back, mottled where it settles.
float wakeDust=carWake.y>0.?carWake.z*smoothstep(carWake.x+carWake.y,carWake.x+carWake.y*.15,vCoatingRest.z)*(.55+.45*coatingNoise(vCoatingRest*vec3(16.,24.,16.)+carSurfacePhase*3.)):0.;
// Settled dust: the event's dust in the air lies on the faces that look up, roof, bonnet and boot (same film as the wake dust).
#ifndef FLAT_SHADED
wakeDust=max(wakeDust,carTopDust*smoothstep(.35,.85,dot(normalize(vNormal),normalize((viewMatrix*vec4(0.,1.,0.,0.)).xyz)))*(.6+.4*coatingNoise(vCoatingRest*vec3(22.,9.,22.)+carSurfacePhase*5.)));
#endif
${glass?`carDirt*=.1;carWet=moisture*.35;
float droplets=smoothstep(.73,.87,coatingNoise(vCoatingRest*vec3(130.,40.,95.)))*carWet;
diffuseColor.a=clamp(diffuseColor.a+droplets*.11,0.,.98);
diffuseColor.a=clamp(diffuseColor.a+wakeDust*.6,0.,.97);`:''}
diffuseColor.rgb=mix(diffuseColor.rgb,vec3(.185,.148,.103)*mix(1.,.66,carWet),carDirt);
diffuseColor.rgb*=1.-carWet*.08;
diffuseColor.rgb=mix(diffuseColor.rgb,vec3(${new T.Color(WAKE.tint).toArray().map(v=>v.toFixed(3)).join(',')})*mix(1.,.62,carWet),wakeDust*${glass?'.85':'.8'});
`)
          .replace('#include <roughnessmap_fragment>',`${glass?'':`float transferred=vTransferredPaint.a*(.48+.52*siltPattern);
diffuseColor.rgb=mix(diffuseColor.rgb,vTransferredPaint.rgb,transferred*.85);`}
#include <roughnessmap_fragment>
roughnessFactor=mix(roughnessFactor,.95,ageRust);
roughnessFactor=mix(roughnessFactor,.89,max(carDirt*.8,wakeDust*.9));
roughnessFactor=mix(roughnessFactor,max(.1,roughnessFactor*.48),carWet*(1.-carDirt*.55));`)
          .replace('#include <metalnessmap_fragment>','#include <metalnessmap_fragment>\nmetalnessFactor*=(1.-carDirt*.9)*(1.-wakeDust*.8)*(1.-ageRust);')
          // A lamp under dust or dirt glows dimmer through the grime.
          .replace('#include <emissivemap_fragment>',`#include <emissivemap_fragment>\ntotalEmissiveRadiance*=1.-clamp(wakeDust*${LAMP_GRIME.dust}+carDirt*${LAMP_GRIME.dirt},0.,${LAMP_GRIME.most});`)
          .replace('#include <lights_physical_fragment>',`#include <lights_physical_fragment>
#ifdef USE_CLEARCOAT
material.clearcoat*=(1.-carDirt*.88)*(1.-wakeDust*.85)*(1.-max(ageRust,rustStain*.6));
material.clearcoatRoughness=mix(material.clearcoatRoughness,.07,carWet);
#endif`);
      };
      m.customProgramCacheKey=()=>key+'-persistent-wet-silt-wake-v5-'+Number(glass)+(rusts(m.name)?'-rust':'');
    });
  }
  advance(dt:number,speed:number,gravel:boolean,wet:readonly boolean[],grounded:readonly boolean[]=[true,true,true,true]){
    if(!(dt>0)||!Number.isFinite(dt))return;
    const distance=Math.abs(speed)*dt;this.distance+=distance;
    const v=this.coating.value;
    v.x*=Math.exp(-dt*(.014+Math.abs(speed)*.0007));v.y*=Math.exp(-dt*(.014+Math.abs(speed)*.0007));
    for(let i=0;i<4;i++){
      this.water[i]=wet[i]?1:this.water[i]*Math.exp(-distance*.035-dt*.03);
      const side=i%2?'y':'x',dirt=i%2?'w':'z';
      if(wet[i]&&Math.abs(speed)>.7)v[side]=Math.min(1,v[side]+dt*Math.min(2,Math.abs(speed)*.13));
      if(grounded[i]&&gravel&&Math.abs(speed)>1.4)v[dirt]=Math.min(.9,v[dirt]+distance*(wet[i]?.00065:.00011));
    }
  }
  transfer(mesh:T.Mesh,contact:T.Vector3,damage:number,color?:T.Color){
    if(!color)return;
    const attribute=mesh.geometry.attributes.transferPaint,position=mesh.geometry.attributes.position,toModel=mesh.userData.wreckToModel as T.Matrix4;
    if(!attribute||!position||!toModel)return;
    const p=new T.Vector3(),radius=.55+Math.min(23,damage)*.02;
    for(let i=0;i<position.count;i++){
      const weight=Math.max(0,1-p.fromBufferAttribute(position,i).applyMatrix4(toModel).distanceTo(contact)/radius);
      if(weight<=0)continue;
      const alpha=Math.min(.8,attribute.getW(i)+weight*damage*.012);
      attribute.setXYZW(i,color.r,color.g,color.b,alpha);
    }
    attribute.needsUpdate=true;
  }
  /** Dust in the wake on the tail, back of the bodywork at rear (model frame z), this dusty. */
  placeWake(rear:number,level:number){this.wake.value.set(rear,WAKE.reach,Math.max(0,level),0);}
  /** Rust where this fit says the car rots, this far gone (0–1). */
  placeRust(fit:RustFit,age:number){this.rust.value.set(Number.isFinite(age)?Math.max(0,Math.min(1,age)):0,fit.bottom,fit.halfWidth,fit.frontArch);this.arches.value.set(fit.front,fit.rear,fit.hub,fit.rearArch);}
  get rustAge(){return this.rust.value.x;}
  set rustAge(age:number){if(this.rust.value.z>0)this.rust.value.x=Number.isFinite(age)?Math.max(0,Math.min(1,age)):0;}
  get wakePlaced(){return this.wake.value.y>0;}
  get wakeLevel(){return this.wake.value.z;}
  set wakeLevel(level:number){if(this.wake.value.y>0)this.wake.value.z=Number.isFinite(level)?Math.max(0,level):0;}
  reset(){this.coating.value.set(0,0,0,0);this.water.fill(0);this.distance=0;}
  get stats(){return{wet:[this.coating.value.x,this.coating.value.y],dirt:[this.coating.value.z,this.coating.value.w],tires:Array.from(this.water),distance:this.distance};}
}
