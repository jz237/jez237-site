// QA: drivers get out of burning cars. Four-car derby, rivals' engines dead: rival 1 is parked side-on 8 m ahead and set alight,
// rival 2 is blown up further off. After the fire takes hold the drivers' walks are printed (__quarry.bailed) and rival 1's side is
// each standing driver is photographed with their car (work/driver-bail/out-N.jpg). Reports page errors.
import {chromium} from '@playwright/test';
const port=process.env.PORT??'8795';
const browser=await chromium.launch({channel:'chrome',headless:true,args:['--ignore-gpu-blocklist','--enable-gpu']});const errors=[];
try{const page=await browser.newPage({viewport:{width:1280,height:720}});page.on('pageerror',e=>errors.push(e.message.slice(0,160)));page.on('console',m=>{if(m.type()==='error')errors.push(m.text().slice(0,160));});
 await page.goto(`http://127.0.0.1:${port}/`);await page.waitForSelector('#start',{timeout:240000});
 await page.evaluate(()=>{const o=JSON.parse(localStorage.getItem('quarry-impact-events-v1')??'{"version":1}');Object.assign(o,{version:1,field:4,arena:'harrow-bowl-v1',derby:'survival',duration:180});localStorage.setItem('quarry-impact-events-v1',JSON.stringify(o));});
 await page.reload();await page.waitForSelector('#start',{timeout:240000});await page.click('.mode-card[data-mode="derby"]');await page.click('#start');
 await page.waitForFunction(()=>window.__quarry?.state==='playing',null,{timeout:180000});await page.evaluate(()=>__quarry.mute?.());await page.waitForTimeout(800);
 await page.evaluate(()=>{const [px,,pz]=__quarry.inspect()[0].position;for(const i of [1,2,3])__quarry.setEngineDamage(i,1);
  __quarry.teleport(1,px,pz+8,Math.PI/2);__quarry.teleport(2,px+22,pz+26,0);__quarry.teleport(3,px-60,pz+60,0);});
 await page.waitForTimeout(1500);await page.evaluate(()=>{__quarry.setAlight(1);__quarry.blowUp(2);});
 const trace=[];for(let k=0;k<8;k++){await page.waitForTimeout(700);trace.push(await page.evaluate(()=>__quarry.bailed().length));}
 const out=await page.evaluate(()=>__quarry.bailed());
 // Each standing driver from beyond them, looking back at them and their car.
 for(const [k,d] of out.entries()){await page.evaluate(({at:[x,y,z]})=>{const near=__quarry.inspect().map(c=>c.position).sort((a,b)=>Math.hypot(a[0]-x,a[2]-z)-Math.hypot(b[0]-x,b[2]-z))[0],dx=x-near[0],dz=z-near[2],n=Math.hypot(dx,dz)||1;
   if(__quarry.state==='paused')__quarry.resume();__quarry.captureCamera([x+dx/n*3.6+dz/n*1.2,y+.5,z+dz/n*3.6-dx/n*1.2],[x-dx/n*1.4,y-.5,z-dz/n*1.4]);document.querySelectorAll('.hud,.overlay,.toast,#overlay').forEach(e=>e.style.display='none');},d);
  await page.waitForTimeout(450);await page.screenshot({path:`work/driver-bail/out-${k}.jpg`,quality:90});}
 console.log(JSON.stringify({trace,out,fire:await page.evaluate(()=>__quarry.inspect()[1].onFire??null),errors:errors.slice(0,3)}));
}finally{await browser.close();}
